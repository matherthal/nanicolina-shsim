package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchJoinContext;

public class JoinHandlerWithCost {
	
	private int joinCounter;
	private boolean joinOk;	
	
	public boolean isJoinOk() {
		return joinOk;
	}
	
	public int getJoinCounter() {
		return joinCounter;
	}

	@Handler({
			"java(,world,)://world.equals(\"World\")",
			"java(hello,world,i)://AND(i+((int) 'A')> (int) hello.charAt(0),i+((int) 'A')< (int) world.charAt(0))"
		})
	public void join(
			LocalEventDispatchJoinContext<Object, Integer, Object> context, 
			@Condition("COST(2*20,\"Hello\".equals(hello))") String hello, 
			String world, 
			int i) {
		++joinCounter;
		joinOk = "Hello".equals(hello) && "World".equals(world) && i>'H'-'A' && i<'W'-'A';
		
		context.post(hello+" "+world+" "+i);
	}
}
