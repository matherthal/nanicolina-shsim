package com.hammurapi.eventbus.tests.fastfood;

import java.util.Random;

import com.hammurapi.eventbus.local.LocalEventBus;

public class Cashier extends Thread {

	private LocalEventBus<Object, ?, ?> bus;
	private final int numberOfOrders;
	private Random random;

	public Cashier(int numberOfOrders, LocalEventBus<Object, ?, ?> eventBus) {
		this.bus = eventBus;
		this.numberOfOrders = numberOfOrders;
		this.random = new Random(System.currentTimeMillis()+this.hashCode());
	}
	
	@Override
	public void run() {
		try {
			for (int i=0; i<numberOfOrders; ++i) {
				Class<? extends MainDish> mainDishType = random.nextBoolean() ? Hamburger.class : Cheeseburger.class;
				Class<? extends SideDish> sideDishType = random.nextBoolean() ? FrenchFries.class : Coleslaw.class;
				bus.post(new Order(mainDishType, sideDishType));
				Thread.sleep(random.nextInt(100));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
