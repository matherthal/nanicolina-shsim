package com.hammurapi.eventbus.tests.fastfood;

public class SideDish extends Dish {

}
