package com.hammurapi.eventbus.tests.fastfood;

public class Hamburger extends MainDish {

}
