package com.hammurapi.eventbus.tests.fastfood;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicInteger;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchJoinContext;

/**
 * Handler which fulfills orders.
 * @author Pavel Vlasov
 *
 */
public class OrderFulfiller {
	
	private AtomicInteger failureCounter = new AtomicInteger();
	
	@Handler("java(*)://order.getMainDishType().equals(mainDish.getClass())")
	public void matchMainDish(LocalEventDispatchJoinContext<Object, Integer, Object> ctx, Order order, MainDish mainDish) {
		if (order.setMainDish(mainDish)) {
			ctx.consume(mainDish);
			if (order.isFulfilled()) {
				ctx.consume(order);
				fulfilledOrders.add(order);
			} else {
				ctx.consumeJoin(order);
			}
		} else {
			failureCounter.incrementAndGet();
		}
	}

	@Handler("java(*)://order.getSideDishType().equals(sideDish.getClass())")
	public void matchSideDish(LocalEventDispatchJoinContext<Object, Integer, Object> ctx, Order order, SideDish sideDish) {
		if (order.setSideDish(sideDish)) {
			ctx.consume(sideDish);
			if (order.isFulfilled()) {
				ctx.consume(order);
				fulfilledOrders.add(order);
			} else {
				ctx.consumeJoin(order);
			}
		} else {
			failureCounter.incrementAndGet();
		}
	}
	
	public boolean isOK() {
		return failureCounter.get()==0;
	}
	
	private Collection<Order> fulfilledOrders = Collections.synchronizedCollection(new HashSet<Order>());
	
	public Collection<Order> getFulfilledOrders() {
		return fulfilledOrders;
	}

}
