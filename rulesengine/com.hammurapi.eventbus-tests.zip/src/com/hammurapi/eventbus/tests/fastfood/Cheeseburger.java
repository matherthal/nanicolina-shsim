package com.hammurapi.eventbus.tests.fastfood;

public class Cheeseburger extends MainDish {

}
