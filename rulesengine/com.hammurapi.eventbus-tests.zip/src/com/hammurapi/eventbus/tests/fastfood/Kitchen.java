package com.hammurapi.eventbus.tests.fastfood;

import java.util.Random;

import com.hammurapi.eventbus.local.LocalEventBus;

/**
 * Kitchen randomly produces main and side dishes with random interval between productions
 * @author Pavel Vlasov
 *
 */
public class Kitchen extends Thread {
	
	private LocalEventBus<Object, ?, ?> bus;
	private int numberOfDishes;
	private Random random;

	public Kitchen(int numberOfDishes, LocalEventBus<Object, ?, ?> eventBus) {
		this.bus = eventBus;
		this.numberOfDishes = numberOfDishes;
		this.random = new Random(System.currentTimeMillis()+this.hashCode());
	}
	
	@Override
	public void run() {
		try {
			for (int i=0; i<numberOfDishes; ++i) {
				switch (random.nextInt(4)) {
				case 0:
					bus.post(new Hamburger());
					break;
				case 1:
					bus.post(new Cheeseburger());
					break;
				case 2:
					bus.post(new FrenchFries());
					break;
				case 3:
					bus.post(new Coleslaw());
					break;
				}
				Thread.sleep(random.nextInt(50));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
