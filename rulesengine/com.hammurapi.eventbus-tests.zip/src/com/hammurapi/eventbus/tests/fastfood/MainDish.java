package com.hammurapi.eventbus.tests.fastfood;

public class MainDish extends Dish {

}
