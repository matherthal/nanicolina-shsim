package com.hammurapi.eventbus.tests.fastfood;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Pavel Vlasov
 *
 */
public class Order {
	
	private static AtomicInteger INSTANCE_COUNTER = new AtomicInteger();
	
	private final int instanceId = INSTANCE_COUNTER.incrementAndGet();
	
	private Class<? extends MainDish> mainDishType;
	private Class<? extends SideDish> sideDishType;
	private MainDish mainDish;
	private SideDish sideDish;
		
	public Order(Class<? extends MainDish> mainDishType, Class<? extends SideDish> sideDishType) {
		super();
		this.mainDishType = mainDishType;
		this.sideDishType = sideDishType;
	}
	
	public Class<? extends MainDish> getMainDishType() {
		return mainDishType;
	}
	
	public Class<? extends SideDish> getSideDishType() {
		return sideDishType;
	}

	public MainDish getMainDish() {
		return mainDish;
	}

	/**
	 * Sets main dish
	 * @param mainDish
	 * @return true if success, false if main dish is of the wrong type or already consumed.
	 */
	public boolean setMainDish(MainDish mainDish) {
		if (this.mainDish==null) {
			if (mainDishType.isInstance(mainDish)) {
				if (mainDish.consume()) {
					this.mainDish = mainDish;
					return true;
				}
			} else {
				System.err.println("Wrong main dish: "+mainDish+", expected "+mainDishType);
			}
		} else {
			System.err.println("Order already has main dish: "+this);
		}
		return false;
	}

	public SideDish getSideDish() {
		return sideDish;
	}

	/**
	 * Sets side dish
	 * @param sideDish
	 * @return true if success, false if side dish is of wrong type or already consumed.
	 */
	public boolean setSideDish(SideDish sideDish) {
		if (this.sideDish==null) {
			if (sideDishType.isInstance(sideDish)) {
				if (sideDish.consume()) {
					this.sideDish = sideDish;
					return true;
				}
			} else {
				System.err.println("Wrong side dish: "+sideDish+", expected "+sideDishType);
			}
		} else {
			System.err.println("Order already has side dish: "+this);
		}
		return false;
	}
	
	public boolean isFulfilled() {
		return mainDish!=null && sideDish!=null;
	}

	@Override
	public String toString() {
		return "Order [" + instanceId + "]";
	}	

}
