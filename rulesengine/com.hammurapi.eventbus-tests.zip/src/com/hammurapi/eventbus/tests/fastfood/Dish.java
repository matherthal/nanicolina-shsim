package com.hammurapi.eventbus.tests.fastfood;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Dish {
	
	private static AtomicInteger INSTANCE_COUNTER = new AtomicInteger();
	
	private AtomicBoolean consumed = new AtomicBoolean(false);
	
	private final int instanceId = INSTANCE_COUNTER.incrementAndGet();
	
	/**
	 * Consumes dish
	 * @return true if dish successfully consumed. Dish can be consumed only once.
	 */
	public boolean consume() {
		if (consumed.getAndSet(true)) {
			System.err.println("Already consumed: "+this);
		}
		return true;
	}
	
	public boolean isConsumed() {
		return consumed.get();
	}
	
	@Override
	public String toString() {
		String cName = getClass().getName();
		int idx = cName.lastIndexOf('.');
		return cName.substring(idx+1)+" ("+instanceId+")";
	}

}
