package com.hammurapi.eventbus.tests.fastfood;

public class FrenchFries extends SideDish {

}
