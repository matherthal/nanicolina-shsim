package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;

public class PredicateChainingHandler {
	
	private boolean oneInvoked;
	private boolean twoInvoked;
		
	@Handler
	public void handleOne(@Condition("java(*)://str.length()>10 && str.startsWith(\"Hello\")") String str) {
		oneInvoked = true;
	}
	
	@Handler("java(*)://AND(str.length()>10, str.endsWith(\"world!\"))")
	public void handleTwo(String str) {
		twoInvoked = true;
	}

	public boolean isOneInvoked() {
		return oneInvoked;
	}
	
	public boolean isTwoInvoked() {
		return twoInvoked;
	}
	
}
