package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class StringHandlerWithMethodCondition {
	
	private int counter;
	private boolean ok;

	public int getCounter() {
		return counter;
	}
	
	public boolean isOk() {
		return ok;
	}
	
	@Handler("java(str)://str.equals(\"Hello\")")
	public void handle(String str) {
		++counter;
		ok = "Hello".equals(str);
	}
	
}
