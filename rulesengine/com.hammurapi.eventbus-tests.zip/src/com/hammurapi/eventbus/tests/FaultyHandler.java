package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class FaultyHandler {
	
	@Handler
	public void handle(String str) {
		throw new RuntimeException("Oops!");
	}
	
}
