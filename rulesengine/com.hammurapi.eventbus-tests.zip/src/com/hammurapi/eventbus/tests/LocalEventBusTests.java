/**
 * 
 */
package com.hammurapi.eventbus.tests;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertSame;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hammurapi.common.MapTokenSource;
import com.hammurapi.common.Observable;
import com.hammurapi.common.ObservableConverter;
import com.hammurapi.common.Observer;
import com.hammurapi.common.TokenExpander;
import com.hammurapi.common.TokenExpander.TokenSource;
import com.hammurapi.eventbus.AbstractEventBus.Handle;
import com.hammurapi.eventbus.Derivation;
import com.hammurapi.eventbus.DuplicatesFilter;
import com.hammurapi.eventbus.EventDispatchContext;
import com.hammurapi.eventbus.EventDispatchException;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.InferenceChainLengthFilter;
import com.hammurapi.eventbus.InferenceFilter;
import com.hammurapi.eventbus.InferencePolicy;
import com.hammurapi.eventbus.JavaBinderCompiler;
import com.hammurapi.eventbus.local.LocalAbstractEventHandler;
import com.hammurapi.eventbus.local.LocalDispatchNetworkDotSnapshot;
import com.hammurapi.eventbus.local.LocalEventBus;
import com.hammurapi.eventbus.local.LocalEventStore;
import com.hammurapi.eventbus.local.LocalEventStoreImpl;
import com.hammurapi.eventbus.local.LocalIntrospector;
import com.hammurapi.eventbus.local.LocalSimpleMatcher;
import com.hammurapi.eventbus.monitoring.JmxStatsCollector;
import com.hammurapi.eventbus.snapshot.io.SnapshotOutput;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesDispatchNetworkDotSnapshot;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesEventBus;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesEventStore;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesEventStoreImpl;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesIntrospector;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Person;
import com.hammurapi.eventbus.tests.familyties.model.Relative;
import com.hammurapi.eventbus.tests.familyties.model.Spouse;
import com.hammurapi.eventbus.tests.familyties.rules.DaughterRule;
import com.hammurapi.eventbus.tests.familyties.rules.DaughterRuleJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules;
import com.hammurapi.eventbus.tests.familyties.rules.GrandRules;
import com.hammurapi.eventbus.tests.familyties.rules.GrandRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.ParentChildRules;
import com.hammurapi.eventbus.tests.familyties.rules.ParentChildRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.ParentRules;
import com.hammurapi.eventbus.tests.familyties.rules.ParentRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SecondaryRules;
import com.hammurapi.eventbus.tests.familyties.rules.SecondaryRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SiblingRules;
import com.hammurapi.eventbus.tests.familyties.rules.SiblingRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SonRule;
import com.hammurapi.eventbus.tests.familyties.rules.SonRuleJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SpouseRules;
import com.hammurapi.eventbus.tests.familyties.rules.SpouseRulesJavaBinder;
import com.hammurapi.eventbus.tests.fastfood.Cashier;
import com.hammurapi.eventbus.tests.fastfood.Dish;
import com.hammurapi.eventbus.tests.fastfood.Kitchen;
import com.hammurapi.eventbus.tests.fastfood.Order;
import com.hammurapi.eventbus.tests.fastfood.OrderFulfiller;
import com.hammurapi.extract.AbstractPredicate;
import com.hammurapi.extract.Extractor;
import com.hammurapi.extract.InstanceOfPredicate;
import com.hammurapi.extract.Predicate;

/**
 * @author Pavel Vlasov
 *
 */
public class LocalEventBusTests {
	
	private ExecutorService executorService;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
//		BlockingQueue<Runnable> wq = new ArrayBlockingQueue<Runnable>(1000);
 		executorService = Executors.newFixedThreadPool(2);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
 		executorService.shutdown();
	}	
	
	@Test
	public void testParallelExecution() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (!obf.isUseExecutor() || obf.inferencePolicy!=InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			
			final Thread[] invocationThreads = new Thread[3];
			invocationThreads[0] = Thread.currentThread();
			
			final Object[] handled = {null};
			/**
			 * Predicate is used to record its invocation thread.
			 */
			Predicate<Object,Object> predicate = new AbstractPredicate<Object, Object>(0, null, false, 0) {
	
				@Override
				protected Boolean extractInternal(
						Object context,
						Map<Object, Map<Extractor<Object, ? super Boolean, Object>, ? super Boolean>> cache,
						Object... obj) 
				{				
					invocationThreads[1] = Thread.currentThread();
					return "Test event".equals(obj[0]);
				}
				
			};
	
			/**
			 * Handler which does nothing, just records its invocation thread.
			 */
	 		LocalAbstractEventHandler<Object, Integer, Object> handler = new LocalAbstractEventHandler<Object, Integer, Object>() {
	
				@Override
				public void post(
						EventDispatchContext<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> context,
						Object... events) {
					invocationThreads[2] = Thread.currentThread();
					handled[0] = events[0];
				}
	
			};
			
			handler.setPredicate(predicate);
	
			bus.addHandler(handler);
			
			if (!obf.isUseSimpleMatcher()) {
				takeSnapshot(bus, "snapshots\\snapshot1_"+obf.id+".dot");
			}
			
			final String event = "Test event";
			bus.post(event);
			
			// Without delay tasks will be most likely executed in the main thread.
			Thread.sleep(100);
			
			bus.join();
			
			assertNotNull(invocationThreads[1]);
			assertNotNull(invocationThreads[2]);
//			assertNotSame(invocationThreads[0], invocationThreads[1]); // Can't guarantee that it'll be executed by another thread.
			assertNotSame(invocationThreads[0], invocationThreads[2]);
			assertSame(event, handled[0]);
		}
	}

	private void takeSnapshot(LocalEventBus<Object, Integer, Object> bus, String fileName) {
		bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File(fileName)));
	}
	
	@Test
	public void testSimpleStringHandler() throws InterruptedException {
		for (StringBusFactory sbf: createStringBus(null)) {
			LocalEventBus<String, Integer, Object> bus = sbf.createBus();
		
			LocalIntrospector<String, Object> introspector = new LocalIntrospector<String, Object>(null, null);		
			SimpleStringHandler handler = new SimpleStringHandler();
			introspector.bind(handler, bus);
			
			if (!sbf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<String, Integer, Object>(new File("snapshots\\SimpleStringHandler_"+sbf.id+".dot")));
			}
			
			bus.post("Hello world!");
			bus.join();
			
			assertEquals(1, handler.getCounter());
		}
	}
	
	@Test
	public void testSimpleStringHandler2() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			SimpleStringHandler handler = new SimpleStringHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				takeSnapshot(bus, "snapshots\\SimpleStringHandler2_"+obf.id+".dot");
			}
			
			bus.post("Hello world!");
			bus.join();
			
			assertEquals(1, handler.getCounter());
		}
	}
	
	@Test
	public void testStringHandlerWithMethodCondition() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			StringHandlerWithMethodCondition handler = new StringHandlerWithMethodCondition();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				takeSnapshot(bus, "snapshots\\StringHandlerWithMethodCondition_"+obf.id+".dot");
			}
			
			bus.post("Hello");
			bus.post("World");
			bus.join();
			
			assertEquals(1, handler.getCounter());
			assertTrue(handler.isOk());
		}
	}
	
	@Test
	public void testStringHandlerWithParameterCondition() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			StringHandlerWithParameterCondition handler = new StringHandlerWithParameterCondition();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				takeSnapshot(bus, "snapshots\\StringHandlerWithParameterCondition_"+obf.id+".dot");
			}
			
			bus.post("Hello");
			bus.post("World");
			bus.join();
			
			assertEquals(1, handler.getCounter());
			assertTrue(handler.isOk());
		}
	}
	
	@Test
	public void testParameterizedStringHandlerWithMethodCondition() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			ParameterizedStringHandlerWithMethodCondition handler = new ParameterizedStringHandlerWithMethodCondition();
			handler.setFilterStr("Hello");
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\ParameterizedStringHandlerWithMethodCondition_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post("World");
			bus.join();
			
			assertEquals(1, handler.getCounter());
			assertTrue(handler.isOk());
		}
	}
	
	
	@Test
	public void testTokenParameterizedStringHandlerWithMethodCondition() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			Map<String, String> map = new HashMap<String, String>();
			map.put("filterStr", "\"Hello\"");
			TokenSource ts = new MapTokenSource(map); 
			TokenExpander te = new TokenExpander(ts);
	
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, te);		
			TokenParameterizedStringHandlerWithMethodCondition handler = new TokenParameterizedStringHandlerWithMethodCondition();
					
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\TokenParameterizedStringHandlerWithMethodCondition_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post("World");
			bus.join();
			
			assertEquals(1, handler.getCounter());
			assertTrue(handler.isOk());
		}
	}
	
	@Test
	public void testPost() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			StringHandlerWithMethodCondition helloHandler = new StringHandlerWithMethodCondition();		
			introspector.bind(helloHandler, bus);
			
			PostingHandler ph = new PostingHandler();
			introspector.bind(ph, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\Posting_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("World");
			bus.join();
			
			assertEquals(1, ph.getWorldCounter());
			assertTrue(ph.isWorldOk());
			
			assertEquals("OBF: "+obf, 1, ph.getEmCounter());
			assertTrue(ph.isEmOk());
			
			assertEquals(obf+",  ", 1, helloHandler.getCounter());
			assertTrue(helloHandler.isOk());
		}

	}
	
	@Test
	public void testHandleJoin() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			SlowPostingHandler ph = new SlowPostingHandler();
			introspector.bind(ph, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\HandleJoin_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			Handle<Object, Integer, Object, Long> worldHandle = bus.post("World");
			worldHandle.join();
			
			assertEquals(2, ph.getCounter());
			
			Set<String> words = new HashSet<String>();
			words.add("Hello");
			words.add("World");
			words.add("!");
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				assertTrue(words.remove(h.getEvent()));
			}
			assertTrue(words.isEmpty());
		}
	}
	
	@Test
	public void testJoin() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			JoinHandler joinHandler = new JoinHandler();		
			introspector.bind(joinHandler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\Joining_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post(20);
			bus.post(1000);
			bus.post("Good bye!");
			bus.join();
			
			// Browser snapshot
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\Joining_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
			}
			
			assertEquals(1, joinHandler.getHelloCounter());
			assertEquals(1, joinHandler.getJoinCounter());
			
			assertTrue(joinHandler.isHelloOk());
			assertTrue(joinHandler.isJoinOk());
			
			// Derivation test
			for (Handle<Object,Integer,Object,Long> h: bus.getStore()) {
				Object event = h.getEvent();
				if (String.valueOf(event).startsWith("Hello World")) {
					Collection<Derivation<Object, Integer, Object>> derivations = bus.getDerivations(event);
					System.out.println(derivations);
				}
			}
		}
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testBinderCompiler() {
		JavaBinderCompiler compiler = new JavaBinderCompiler(new File("generated.tests"));
		
		compiler.compileJavaBinder(JoinHandler.class, LocalEventBus.class, null, null);		
	}
	
	@Test
	public void testFamilyTiesBindingCompilation() {
		JavaBinderCompiler compiler = new JavaBinderCompiler(new File("generated.tests"));
		
		compiler.compileJavaBinder(DaughterRule.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(GrandRules.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(ParentChildRules.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(ParentRules.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(SecondaryRules.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(SiblingRules.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(SonRule.class, FamilyTiesEventBus.class, null, null);		
		compiler.compileJavaBinder(SpouseRules.class, FamilyTiesEventBus.class, null, null);		
	}
	
	@Test
	public void testCompiledJoin() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			JoinHandler joinHandler = new JoinHandler();
			JoinHandlerJavaBinder joinHandlerJavaBinder = new JoinHandlerJavaBinder();
			joinHandlerJavaBinder.bind(joinHandler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\Joining_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post(20);
			bus.post(1000);
			bus.post("Good bye!");
			bus.join();
			
			if (!obf.isUseSimpleMatcher()) {
				// Browser snapshot
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\CompiledJoining"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
			}
			
			assertEquals(1, joinHandler.getHelloCounter());
			assertEquals(1, joinHandler.getJoinCounter());
			
			assertTrue(joinHandler.isHelloOk());
			assertTrue(joinHandler.isJoinOk());
			
			// Derivation test
			for (Handle<Object,Integer,Object,Long> h: bus.getStore()) {
				Object event = h.getEvent();
				if (String.valueOf(event).startsWith("Hello World")) {
					Collection<Derivation<Object, Integer, Object>> derivations = bus.getDerivations(event);
					System.out.println(derivations);
				}
			}
		}		
	}
	
	@Test
	public void testJoinWithCost() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			JoinHandlerWithCost joinHandler = new JoinHandlerWithCost();		
			introspector.bind(joinHandler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\JoiningWithCost_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post(20);
			bus.post(1000);
			bus.post("World");
			bus.join();
			
			assertEquals(1, joinHandler.getJoinCounter());
			assertTrue(joinHandler.isJoinOk());
		}
	}
	
	@Test
	public void testParameterNamesJoin() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			ParameterNamesJoinHandler joinHandler = new ParameterNamesJoinHandler();		
			introspector.bind(joinHandler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\ParameterNamesJoining_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			bus.post("Hello");
			bus.post(20);
			bus.post(1000);
			bus.post("Good bye!");
			bus.join();
			
			assertEquals(1, joinHandler.getHelloCounter());
			assertEquals(1, joinHandler.getJoinCounter());
			
			assertTrue(joinHandler.isHelloOk());
			assertTrue(joinHandler.isJoinOk());
		}
		
	}
	
	@Test
	public void testPriority() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (obf.inferencePolicy.compareTo(InferencePolicy.AFTER_HANDLER)>=0) {
				continue; // Priorities work only if inference commands are processed after handler or immediately.
			}
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			PriorityHandler priorityHandler = new PriorityHandler();		
			introspector.bind(priorityHandler, bus);
			
			bus.post("World");
			bus.post("Hello");
			bus.join();
			
			assertEquals(obf+", ", 1, priorityHandler.getLpCounter());
			assertEquals(obf+", ", 2, priorityHandler.getHpCounter());
			assertEquals(obf+", ", 2, priorityHandler.getAhpCounter());
		}
	}
	
	@Test
	public void testOneOff() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			final AtomicInteger counter = new AtomicInteger();
	
			LocalAbstractEventHandler<Object, Integer, Object> eh = new LocalAbstractEventHandler<Object, Integer, Object>(1, 0, null, false, true, Mode.POST) {
	
	
				@Override
				public void post(
						EventDispatchContext<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> context,
						Object... events) {
					
					counter.incrementAndGet();				
				}
			};
			
			bus.addHandler(eh);
			
			bus.post("World");
			bus.post("Hello");
			bus.post("!");
			bus.join();
			
			assertEquals(1, counter.get());
		}
	}
	
	@Test
	public void testConsumeJoin() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			if (!obf.pkStore) {
				continue;
			}
			
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			OrderFulfiller orderFulfiller = new OrderFulfiller();
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			introspector.bind(orderFulfiller, bus);
	
			if (!obf.isUseSimpleMatcher()) {
				LocalDispatchNetworkDotSnapshot<Object, Integer, Object> snapshot = new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\ConsumeJoin_"+obf.id+".dot"));
				snapshot.setGraphAttribute("dpi", "70");
				bus.takeSnapshot(snapshot);
			}
			
			int totalNumberOfDishes = 800;		
			Kitchen kitchen = new Kitchen(totalNumberOfDishes, bus);
			
			int totalNumberOfOrders = 500;
			Cashier cashier = new Cashier(totalNumberOfOrders, bus);
			
			kitchen.start();
			cashier.start();
	
			kitchen.join();
			cashier.join();
			bus.join();
			Thread.sleep(5000);
			
			assertTrue(orderFulfiller.isOK());
			
			int fulfilledOrders = 0;
			for (Order o: orderFulfiller.getFulfilledOrders()) {
				assertTrue(o.isFulfilled());
				++fulfilledOrders;
			}
			
			int partialOrderDishes = 0;
			int unfulfilledOrders = 0;
			Predicate<Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> orderSelector = new InstanceOfPredicate<Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>>(bus.getStore().getPrimaryKeyExtractor(), Order.class);
			for (Object event: bus.getStore().get(orderSelector, bus.getStore().getPrimaryKeyExtractor(), false, null)) {
				Order order = (Order) event;
				assertNotNull(order);
				assertFalse(order.isFulfilled());
				if (order.getMainDish()!=null) {
					++partialOrderDishes;
				}
				if (order.getSideDish()!=null) {
					++partialOrderDishes;
				}
				assertFalse(orderFulfiller.getFulfilledOrders().contains(order));
				++unfulfilledOrders;
			}
			assertEquals(totalNumberOfOrders, fulfilledOrders+unfulfilledOrders);
			
			int remainingDishes = 0;
			Predicate<Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> dishSelector = new InstanceOfPredicate<Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>>(bus.getStore().getPrimaryKeyExtractor(), Dish.class);
			for (Handle<Object, Integer, Object, Long> h: bus.getStore().get(dishSelector)) {
				Dish dish = (Dish) h.getEvent();
				assertNotNull(dish);
				assertFalse(dish.isConsumed());
				++remainingDishes;
			}
			assertEquals(totalNumberOfDishes, fulfilledOrders*2+remainingDishes+partialOrderDishes);
		}		
	}

	@Test
	public void testPredicateChaining() throws InterruptedException {
		for (StringBusFactory obf: createStringBus(null)) {
			LocalEventBus<String, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<String, Object> introspector = new LocalIntrospector<String, Object>(null, null);		
			PredicateChainingHandler handler = new PredicateChainingHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<String, Integer, Object>(new File("snapshots\\PredicateChainingHandler_"+obf.id+".dot")));
			}
			
			bus.post("Hello world!");
			bus.join();
			
			assertTrue(handler.isOneInvoked());
			assertTrue(handler.isTwoInvoked());
		}
	}
	
	@Test
	public void testOppositeChaining() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			OppositeHandler handler = new OppositeHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\OppositeHandler_"+obf.id+".dot")));
			}
			
			bus.post("Hello world!");
			bus.join();
			
			assertFalse(handler.isOneInvoked());
			assertTrue(handler.isTwoInvoked());
		}
	}
	
	@Test
	public void testMoreRestrictive() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			MoreRestrictiveHandler handler = new MoreRestrictiveHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\MoreRestrictiveHandler_"+obf.id+".dot")));
			}
			
			bus.post(Collections.singleton("Hello"));
			bus.join();
			
			assertTrue(handler.isCollectionInvoked());
			assertFalse(handler.isListInvoked());
		}
	}
	
	@Test
	public void testLoop() throws InterruptedException {
		DuplicatesFilter iFilter = new DuplicatesFilter();
		for (ObjectBusFactory obf: createObjectBus(iFilter)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			LoopHandler handler = new LoopHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\LoopHandler_"+obf.id+".dot")));
			}
			
			bus.post("Hello");
			bus.post("Good bye!");
			bus.join();
			
			assertTrue(handler.isHelloOk());
			assertEquals(1, handler.getHelloCounter());
			
			assertTrue(handler.isWorldOk());
			assertEquals(1, handler.getWorldCounter());
		}
	}
	
	@Test
	public void testInifinite() throws InterruptedException {
		InferenceFilter iFilter = new InferenceChainLengthFilter(100);
		for (ObjectBusFactory obf: createObjectBus(iFilter)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			bus.setMaxDerivationDepth(100);
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			InfiniteHandler handler = new InfiniteHandler();
			introspector.bind(handler, bus);
			
			if (!obf.isUseSimpleMatcher()) {
				bus.takeSnapshot(new LocalDispatchNetworkDotSnapshot<Object, Integer, Object>(new File("snapshots\\InfiniteHandler_"+obf.id+".dot")));
			}
			
			Handle<Object, Integer, Object, Long> handle = bus.post("Hello");
			handle.join();
		}
	}
	
	@Test(expected=EventDispatchException.class)
	public void testFaulty() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			FaultyHandler handler = new FaultyHandler();
			introspector.bind(handler, bus);
			
			Handle<Object, Integer, Object, Long> handle = bus.post("Hello");
			handle.join();
		}
	}

	@Test
	public void testRemoveHandler() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			SimpleStringHandler handler = new SimpleStringHandler();
			Set<Long> keys = introspector.bind(handler, bus);
			
			Handle<Object, Integer, Object, Long> handle = bus.post("Hello");
			handle.join();
			assertEquals(1, handler.getCounter());
			
			bus.removeHandlers(keys);
			
			SimpleStringHandler handler2 = new SimpleStringHandler();
			introspector.bind(handler2, bus);
			
			Handle<Object, Integer, Object, Long> handle2 = bus.post("Good bye!");
			handle2.join();
			assertEquals(1, handler.getCounter());
			assertEquals(1, handler2.getCounter());
		}		
	}
	
	@Test
	public void testReset() throws InterruptedException {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
		
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);		
			StatefulHandler handler = new StatefulHandler();
			Set<Long> keys = introspector.bind(handler, bus);
			
			bus.post("Hello");
			bus.post("1");
			bus.join();
			
			assertEquals(2, handler.getState().size());
			int kbSize = 0;
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				++kbSize;
			}
			assertEquals(2, kbSize);
			assertEquals(0, handler.getResetCounter());
			
			bus.reset();
			
			assertEquals(0, handler.getState().size());
			kbSize = 0;
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				++kbSize;
			}
			assertEquals(0, kbSize);
			assertEquals(2, handler.getResetCounter());
		}				
	}
	
	private static int predicateCounter;
	
	/**
	 * Helper interface for intantiate bus for tests.
	 * @author Pavel Vlasov
	 *
	 * @param <E>
	 * @param <P>
	 * @param <C>
	 */
	private class ObjectBusFactory {
		
		private InferencePolicy inferencePolicy;
		private boolean pkStore;
		private boolean useExecutor;
		private InferenceFilter iFilter;
		private int id;
		private boolean useSimpleMatcher;
		private ObservableConverter<Object> observableConverter;

		public ObjectBusFactory(InferencePolicy inferencePolicy, InferenceFilter iFilter, boolean pkStore, boolean useExecutor, int id, boolean useSimpleMatcher) {
			this.inferencePolicy = inferencePolicy;
			this.pkStore = pkStore;
			this.useExecutor = useExecutor;
			this.iFilter = iFilter;
			this.id = id;
			this.useSimpleMatcher = useSimpleMatcher;
		}
		
		public boolean isUseExecutor() {
			return useExecutor;
		}
		
		public boolean isUseSimpleMatcher() {
			return useSimpleMatcher;
		}
		
		public InferencePolicy getInferencePolicy() {
			return inferencePolicy;
		}
		
		@Override
		public String toString() {
			return "ObjectBusFactory [inferencePolicy=" + inferencePolicy
					+ ", pkStore=" + pkStore + ", useExecutor=" + useExecutor
					+ ", iFilter=" + iFilter + ", id=" + id + ", useSimpleMatcher="+useSimpleMatcher+"]";
		}
		
		public void setObservableConverter(ObservableConverter<Object> observableConverter) {
			this.observableConverter = observableConverter;
		}

		LocalEventBus<Object, Integer, Object> createBus() {
			LocalEventStoreImpl.Config<Object, Integer, Object> storeConfig = new LocalEventStoreImpl.Config<Object, Integer, Object>();
			if (!pkStore) {
				storeConfig.setPrimaryKeyExtractor(null);
			}
			if (useExecutor) {
				storeConfig.setExecutorService(executorService);
			}
			LocalEventStore<Object, Integer, Object> eventStore = new LocalEventStoreImpl<Object, Integer, Object>(storeConfig);
			
			LocalEventBus.Config<Object, Integer, Object> busConfig = new LocalEventBus.Config<Object, Integer, Object>();
			busConfig.setEventType(Object.class);
			busConfig.setStore(eventStore);
			if (useExecutor) {
				busConfig.setExecutorService(executorService);
			}
			busConfig.setInferencePolicy(inferencePolicy);
			busConfig.setInferenceFilter(iFilter);
			if (useSimpleMatcher) {
				busConfig.setMatcher(new LocalSimpleMatcher<Object, Integer, Object, LocalEventStore<Object,Integer,Object>>());
			}
			
			busConfig.setObservableConverter(observableConverter);
			
			return new LocalEventBus<Object, Integer, Object>(busConfig) {
				
//				/**
//				 * For troubleshooting.
//				 */
//				public Long addHandler(
//						EventHandler<Object,Integer,Object,AbstractEventBus.Handle<Object,Integer,Object,Long>,
//						LocalEventStore<Object,Integer,Object>> eventHandler, 
//						boolean oneOff, 
//						Predicate<Object,Object>... predicates) {
	//
//					String timestamp = Long.toString(System.currentTimeMillis(), Character.MAX_RADIX);
//					for (int i=0; i<predicates.length; ++i) {
//						PredicateOutput.output(predicates[i], new File("snapshots\\Predicate-"+(++i)+"-"+timestamp+"-"+i+".snapshot"));			
//					}
//					
//					return super.addHandler(eventHandler, oneOff, predicates);
//				}

			};
		}
		
	}
	/**
	 * Helper interface for instantiate bus for tests.
	 * @author Pavel Vlasov
	 *
	 * @param <E>
	 * @param <P>
	 * @param <C>
	 */
	private class StringBusFactory {
		
		private InferencePolicy inferencePolicy;
		private boolean pkStore;
		private boolean useExecutor;
		private InferenceFilter iFilter;
		private int id;
		private boolean useSimpleMatcher;

		public StringBusFactory(InferencePolicy inferencePolicy, InferenceFilter iFilter, boolean pkStore, boolean useExecutor, int id, boolean useSimpleMatcher) {
			this.inferencePolicy = inferencePolicy;
			this.pkStore = pkStore;
			this.useExecutor = useExecutor;
			this.iFilter = iFilter;
			this.id = id;
			this.useSimpleMatcher = useSimpleMatcher;
		}
		
		public boolean isUseExecutor() {
			return useExecutor;
		}
		
		public boolean isUseSimpleMatcher() {
			return useSimpleMatcher;
		}
		
		LocalEventBus<String, Integer, Object> createBus() {
			LocalEventStoreImpl.Config<String, Integer, Object> storeConfig = new LocalEventStoreImpl.Config<String, Integer, Object>();
			if (!pkStore) {
				storeConfig.setPrimaryKeyExtractor(null);
			}
			if (useExecutor) {
				storeConfig.setExecutorService(executorService);
			}
			LocalEventStore<String, Integer, Object> eventStore = new LocalEventStoreImpl<String, Integer, Object>(storeConfig);
			
			LocalEventBus.Config<String, Integer, Object> busConfig = new LocalEventBus.Config<String, Integer, Object>();
			busConfig.setEventType(String.class);
			busConfig.setStore(eventStore);
			if (useExecutor) {
				busConfig.setExecutorService(executorService);
			}
			busConfig.setInferencePolicy(inferencePolicy);
			busConfig.setInferenceFilter(iFilter);
			if (useSimpleMatcher) {
				busConfig.setMatcher(new LocalSimpleMatcher<String, Integer, Object, LocalEventStore<String,Integer,Object>>());
			}
			
			return new LocalEventBus<String, Integer, Object>(busConfig) {
				
//				/**
//				 * For troubleshooting.
//				 */
//				public Long addHandler(
//						EventHandler<Object,Integer,Object,AbstractEventBus.Handle<Object,Integer,Object,Long>,
//						LocalEventStore<Object,Integer,Object>> eventHandler, 
//						boolean oneOff, 
//						Predicate<Object,Object>... predicates) {
	//
//					String timestamp = Long.toString(System.currentTimeMillis(), Character.MAX_RADIX);
//					for (int i=0; i<predicates.length; ++i) {
//						PredicateOutput.output(predicates[i], new File("snapshots\\Predicate-"+(++i)+"-"+timestamp+"-"+i+".snapshot"));			
//					}
//					
//					return super.addHandler(eventHandler, oneOff, predicates);
//				}

			};
		}
		
	}

	private Iterable<ObjectBusFactory> createObjectBus(InferenceFilter iFilter) {
		int counter = 0;
		ArrayList<ObjectBusFactory> ret = new ArrayList<ObjectBusFactory>();
		for (InferencePolicy ip: InferencePolicy.values()) {
			ret.add(new ObjectBusFactory(ip, iFilter, false, false, ++counter, true));
			ret.add(new ObjectBusFactory(ip, iFilter, false, true, ++counter, true));
			ret.add(new ObjectBusFactory(ip, iFilter, true, false, ++counter, true));
			ret.add(new ObjectBusFactory(ip, iFilter, true, true, ++counter, true));
			
			ret.add(new ObjectBusFactory(ip, iFilter, false, false, ++counter, false));
			ret.add(new ObjectBusFactory(ip, iFilter, false, true, ++counter, false));
			ret.add(new ObjectBusFactory(ip, iFilter, true, false, ++counter, false));
			ret.add(new ObjectBusFactory(ip, iFilter, true, true, ++counter, false));
		}
		return ret;
	}

	private Iterable<StringBusFactory> createStringBus(InferenceFilter iFilter) {
		int counter = 0;
		ArrayList<StringBusFactory> ret = new ArrayList<StringBusFactory>();
		for (InferencePolicy ip: InferencePolicy.values()) {
			ret.add(new StringBusFactory(ip, iFilter, false, false, ++counter, true));
			ret.add(new StringBusFactory(ip, iFilter, false, true, ++counter, true));
			ret.add(new StringBusFactory(ip, iFilter, true, false, ++counter, true));
			ret.add(new StringBusFactory(ip, iFilter, true, true, ++counter, true));
			
			ret.add(new StringBusFactory(ip, iFilter, false, false, ++counter, false));
			ret.add(new StringBusFactory(ip, iFilter, false, true, ++counter, false));
			ret.add(new StringBusFactory(ip, iFilter, true, false, ++counter, false));
			ret.add(new StringBusFactory(ip, iFilter, true, true, ++counter, false));
		}
		return ret;
	}
	
	@Test
	public void testFamilyTies() throws InterruptedException {
		int counter = 0;
		for (InferencePolicy ip: InferencePolicy.values()) {
			if (ip==InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			_testFamilyTies(ip, false, false, ++counter, true);
			_testFamilyTies(ip, false, true, ++counter, true);
			_testFamilyTies(ip, true, false, ++counter, true);
			_testFamilyTies(ip, true, true, ++counter, true);
			
			_testFamilyTies(ip, false, false, ++counter, false);
			_testFamilyTies(ip, false, true, ++counter, false);
			_testFamilyTies(ip, true, false, ++counter, false);
			_testFamilyTies(ip, true, true, ++counter, false);			
		}
	}
	
	private void _testFamilyTies(InferencePolicy iPolicy, boolean useExecutor, boolean pkStore, int id, boolean useSimpleMatcher) throws InterruptedException {		
		// Create bus
		FamilyTiesEventStoreImpl.Config storeConfig = new FamilyTiesEventStoreImpl.Config();
		if (useExecutor) {
			storeConfig.setExecutorService(executorService);
		}
		if (!pkStore) {
			storeConfig.setPrimaryKeyExtractor(null);
		}
		FamilyTiesEventStore eventStore = new FamilyTiesEventStoreImpl(storeConfig);
		
		FamilyTiesEventBus.Config busConfig = new FamilyTiesEventBus.Config();
		busConfig.setStore(eventStore);
		if (useExecutor) {
			busConfig.setExecutorService(executorService);
		}
		if (useSimpleMatcher) {
			busConfig.setMatcher(new LocalSimpleMatcher<Relative, Integer, FamilyTiesRules, FamilyTiesEventStore>());
		}
		
		busConfig.setInferencePolicy(iPolicy);
		busConfig.setInferenceFilter(new DuplicatesFilter());
		
		FamilyTiesEventBus bus = new FamilyTiesEventBus(busConfig);
		
		FamilyTiesIntrospector introspector = new FamilyTiesIntrospector(null, null);
		
		// Bind rules.
		introspector.bind(new DaughterRule(), bus);
		introspector.bind(new GrandRules(), bus);
		introspector.bind(new ParentChildRules(), bus);
		introspector.bind(new ParentRules(), bus);
		introspector.bind(new SecondaryRules(), bus);
		introspector.bind(new SiblingRules(), bus);
		introspector.bind(new SonRule(), bus);
		introspector.bind(new SpouseRules(), bus);
		
		if (!useSimpleMatcher) {
			// Take dot snapshot
			bus.takeSnapshot(new FamilyTiesDispatchNetworkDotSnapshot(new File("snapshots\\FamilyTies_"+id+".dot")));
		}

		// Post seed relationships
		Person kate = new Person("Kate", 58, false);
		Person victor = new Person("Victor", 63, true);
		bus.post(new Spouse(kate, victor));

		Person peter = new Person("Peter", 37, true);
		bus.post(new Child(peter, kate));
		bus.post(new Child(peter, victor));
		
		Person alison = new Person("Alison", 36, false);
		bus.post(new Spouse(peter, alison));

		Person lucy = new Person("Lucy", 17, false);
		bus.post(new Child(lucy, alison));
		
		Person nancy = new Person("Nancy", 14, false);
		bus.post(new Child(nancy, peter));
		
		Person dan = new Person("Dan", 7, true);
		bus.post(new Child(dan, peter));
		bus.post(new Child(dan, alison));
		
		Person audrey = new Person("Audrey", 4, false);
		bus.post(new Child(audrey, peter));
		bus.post(new Child(audrey, alison));		
		
		Person tanya = new Person("Tanya", 31, false);
		Person max = new Person("Max", 32, true);
		bus.post(new Spouse(tanya, max));
		bus.post(new Child(tanya, kate));
		bus.post(new Child(tanya, victor));

		Person vilma = new Person("Vilma", 14, false);
		bus.post(new Child(vilma, tanya));
		
		Person george = new Person("George", 10, true);
		bus.post(new Child(george, tanya));
		
		Person lisa = new Person("Lisa", 5, false);
		bus.post(new Child(lisa, tanya));
		bus.post(new Child(lisa, max));		
				
		bus.join();
		
		// Take browser snapshot
		if (!useSimpleMatcher) {
			SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\FamilyTies_"+id+".snapshot"));
			bus.takeSnapshot(emfSnapshot);
		}
		
		int numberOfLisaRelatives = 0;
		for (Relative r: bus.getStore().getRelatives(lisa)) {
			++numberOfLisaRelatives;
		}
		assertEquals(11, numberOfLisaRelatives);
		
		for (Relative relative: bus.getStore().getRelatives(lisa)) {
			System.out.println(relative);
		}
	}
	
	@Test
	public void testCompiledFamilyTies() throws InterruptedException {
		int counter = 0;
		for (InferencePolicy ip: InferencePolicy.values()) {
			if (ip==InferencePolicy.IMMEDIATELY) {
				continue;
			}
			_testCompiledFamilyTies(ip, false, false, ++counter, true);
			_testCompiledFamilyTies(ip, false, true, ++counter, true);
			_testCompiledFamilyTies(ip, true, false, ++counter, true);
			_testCompiledFamilyTies(ip, true, true, ++counter, true);

			_testCompiledFamilyTies(ip, false, false, ++counter, false);
			_testCompiledFamilyTies(ip, false, true, ++counter, false);
			_testCompiledFamilyTies(ip, true, false, ++counter, false);
			_testCompiledFamilyTies(ip, true, true, ++counter, false);
		}
	}
	
	private void _testCompiledFamilyTies(InferencePolicy iPolicy, boolean useExecutor, boolean pkStore, int id, boolean useSimpleMatcher) throws InterruptedException {		
		// Create bus
		// Create bus
		FamilyTiesEventStoreImpl.Config storeConfig = new FamilyTiesEventStoreImpl.Config();
		if (useExecutor) {
			storeConfig.setExecutorService(executorService);
		}
		if (!pkStore) {
			storeConfig.setPrimaryKeyExtractor(null);
		}
		FamilyTiesEventStore eventStore = new FamilyTiesEventStoreImpl(storeConfig);
		
		FamilyTiesEventBus.Config busConfig = new FamilyTiesEventBus.Config();
		busConfig.setStore(eventStore);
		if (useExecutor) {
			busConfig.setExecutorService(executorService);
		}
		busConfig.setInferencePolicy(iPolicy);
		busConfig.setInferenceFilter(new DuplicatesFilter());
		
		if (useSimpleMatcher) {
			busConfig.setMatcher(new LocalSimpleMatcher<Relative, Integer, FamilyTiesRules, FamilyTiesEventStore>());
		}		
		
		FamilyTiesEventBus bus = new FamilyTiesEventBus(busConfig);
		
		// Bind rules.
		new DaughterRuleJavaBinder().bind(new DaughterRule(), bus);
		new GrandRulesJavaBinder().bind(new GrandRules(), bus);
		new ParentChildRulesJavaBinder().bind(new ParentChildRules(), bus);
		new ParentRulesJavaBinder().bind(new ParentRules(), bus);
		new SecondaryRulesJavaBinder().bind(new SecondaryRules(), bus);
		new SiblingRulesJavaBinder().bind(new SiblingRules(), bus);
		new SonRuleJavaBinder().bind(new SonRule(), bus);
		new SpouseRulesJavaBinder().bind(new SpouseRules(), bus);
		
		if (!useSimpleMatcher) {
			// Take dot snapshot
			bus.takeSnapshot(new FamilyTiesDispatchNetworkDotSnapshot(new File("snapshots\\CompiledFamilyTies_"+id+".dot")));
		}

		// Post seed relationships
		Person kate = new Person("Kate", 58, false);
		Person victor = new Person("Victor", 63, true);
		bus.post(new Spouse(kate, victor));

		Person peter = new Person("Peter", 37, true);
		bus.post(new Child(peter, kate));
		bus.post(new Child(peter, victor));
		
		Person alison = new Person("Alison", 36, false);
		bus.post(new Spouse(peter, alison));

		Person lucy = new Person("Lucy", 17, false);
		bus.post(new Child(lucy, alison));
		
		Person nancy = new Person("Nancy", 14, false);
		bus.post(new Child(nancy, peter));
		
		Person dan = new Person("Dan", 7, true);
		bus.post(new Child(dan, peter));
		bus.post(new Child(dan, alison));
		
		Person audrey = new Person("Audrey", 4, false);
		bus.post(new Child(audrey, peter));
		bus.post(new Child(audrey, alison));		
		
		Person tanya = new Person("Tanya", 31, false);
		Person max = new Person("Max", 32, true);
		bus.post(new Spouse(tanya, max));
		bus.post(new Child(tanya, kate));
		bus.post(new Child(tanya, victor));

		Person vilma = new Person("Vilma", 14, false);
		bus.post(new Child(vilma, tanya));
		
		Person george = new Person("George", 10, true);
		bus.post(new Child(george, tanya));
		
		Person lisa = new Person("Lisa", 5, false);
		bus.post(new Child(lisa, tanya));
		bus.post(new Child(lisa, max));		
				
		bus.join();
		
		if (!useSimpleMatcher) {
			// Take browser snapshot
			SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\CompiledFamilyTies.snapshot"));
			bus.takeSnapshot(emfSnapshot);
		}
		
		int numberOfLisaRelatives = 0;
		for (Relative r: bus.getStore().getRelatives(lisa)) {
			++numberOfLisaRelatives;
		}
		assertEquals(11, numberOfLisaRelatives);
		
		for (Relative relative: bus.getStore().getRelatives(lisa)) {
			System.out.println(relative);
		}
	}
	
	@Test
	public void testFamilyTiesJmx() throws InterruptedException {	
		
		// Create bus
		FamilyTiesEventStoreImpl.Config storeConfig = new FamilyTiesEventStoreImpl.Config();
		storeConfig.setExecutorService(executorService);
		FamilyTiesEventStore eventStore = new FamilyTiesEventStoreImpl(storeConfig);
		
		FamilyTiesEventBus.Config busConfig = new FamilyTiesEventBus.Config();
		busConfig.setStore(eventStore);
		busConfig.setExecutorService(executorService);
		busConfig.setInferenceFilter(new DuplicatesFilter());
		
		JmxStatsCollector jsc = new JmxStatsCollector(ManagementFactory.getPlatformMBeanServer(), "Hammurapi Group:root=Family Ties"); 
		busConfig.setStatsCollector(jsc);
		
		FamilyTiesEventBus bus = new FamilyTiesEventBus(busConfig);
		
		Thread.sleep(40000);
		
		FamilyTiesIntrospector introspector = new FamilyTiesIntrospector(null, null);
		
		// Bind rules.
		introspector.bind(new DaughterRule(), bus);
		introspector.bind(new GrandRules(), bus);
		introspector.bind(new ParentChildRules(), bus);
		introspector.bind(new ParentRules(), bus);
		introspector.bind(new SecondaryRules(), bus);
		introspector.bind(new SiblingRules(), bus);
		introspector.bind(new SonRule(), bus);
		introspector.bind(new SpouseRules(), bus);
		
		// Take dot snapshot
		bus.takeSnapshot(new FamilyTiesDispatchNetworkDotSnapshot(new File("snapshots\\FamilyTies_Jmx.dot")));		

		// Post seed relationships
		Person kate = new Person("Kate", 58, false);
		Person victor = new Person("Victor", 63, true);
		bus.post(new Spouse(kate, victor));
		Thread.sleep(2000);

		Person peter = new Person("Peter", 37, true);
		bus.post(new Child(peter, kate));
		Thread.sleep(2000);
		bus.post(new Child(peter, victor));
		Thread.sleep(2000);
		
		Person alison = new Person("Alison", 36, false);
		bus.post(new Spouse(peter, alison));
		Thread.sleep(2000);

		Person lucy = new Person("Lucy", 17, false);
		bus.post(new Child(lucy, alison));
		Thread.sleep(2000);
		
		Person nancy = new Person("Nancy", 14, false);
		bus.post(new Child(nancy, peter));
		Thread.sleep(2000);
		
		Person dan = new Person("Dan", 7, true);
		bus.post(new Child(dan, peter));
		Thread.sleep(2000);
		bus.post(new Child(dan, alison));
		Thread.sleep(2000);
		
		Person audrey = new Person("Audrey", 4, false);
		bus.post(new Child(audrey, peter));
		Thread.sleep(2000);
		bus.post(new Child(audrey, alison));		
		Thread.sleep(2000);
		
		Person tanya = new Person("Tanya", 31, false);
		Person max = new Person("Max", 32, true);
		bus.post(new Spouse(tanya, max));
		Thread.sleep(2000);
		bus.post(new Child(tanya, kate));
		Thread.sleep(2000);
		bus.post(new Child(tanya, victor));
		Thread.sleep(2000);

		Person vilma = new Person("Vilma", 14, false);
		bus.post(new Child(vilma, tanya));
		Thread.sleep(2000);
		
		Person george = new Person("George", 10, true);
		bus.post(new Child(george, tanya));
		Thread.sleep(2000);
		
		Person lisa = new Person("Lisa", 5, false);
		bus.post(new Child(lisa, tanya));
		Thread.sleep(2000);
		bus.post(new Child(lisa, max));		
		Thread.sleep(2000);
				
		Thread.sleep(30000);
		
		bus.join();
		
	}
	
	// --- Remove tests ---
	
	/**
	 * - Post event to the bus
	 * - Check presence
	 * - Remove event using bus.remove()
	 * - Check that event is gone from the store.
	 */
	@Test
	public void testRemoveWithBus() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			PostingHandler ph = new PostingHandler();
			introspector.bind(ph, bus);
						
			bus.post("World");
			bus.join();
			
			assertEquals(1, ph.getWorldCounter());
			assertTrue(ph.isWorldOk());
			
			assertEquals(1, ph.getEmCounter());
			assertTrue(ph.isEmOk());
			
			Set<String> expected = new HashSet<String>();
			expected.add("Hello");
			expected.add("World");
			expected.add("!");
									
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				if (!expected.remove(h.getEvent())) {
					fail("Unexpected object in the store: "+h.getEvent());
				}
			}
			
			if (!expected.isEmpty()) {
				fail("Not present in the store: "+expected);
			}
			
			bus.remove("World");
			bus.join();
			
			for (Object o: bus.getStore()) {
				fail("Unexpected object in the store: "+o);
			}			
		}
	}
	
	/**
	 * - Post event to the bus
	 * - Check presence
	 * - Remove event using Handle.remove()
	 * - Check that event is gone from the store.
	 */
	@Test
	public void testRemoveWithHandle() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			PostingHandler ph = new PostingHandler();
			introspector.bind(ph, bus);
						
			Handle<Object, Integer, Object, Long> wHandle = bus.post("World");
			bus.join();
			
			assertEquals(1, ph.getWorldCounter());
			assertTrue(ph.isWorldOk());
			
			assertEquals(1, ph.getEmCounter());
			assertTrue(ph.isEmOk());
			
			Set<String> expected = new HashSet<String>();
			expected.add("Hello");
			expected.add("World");
			expected.add("!");
						
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				if (!expected.remove(h.getEvent())) {
					fail("Unexpected object in the store: "+h.getEvent());
				}
			}
			
			if (!expected.isEmpty()) {
				fail("Not present in the store: "+expected);
			}
			
			wHandle.remove();
			bus.join();
			
			for (Object o: bus.getStore()) {
				fail("Unexpected object in the store: "+o);
			}			
		}
	}
		
	/**
	 * - Post event
	 * - Validate that remove handler not fired
	 * - Remove event
	 * - Validate event handler fired
	 * @throws Exception
	 */
	@Test
	public void testRemoveHandlers() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();			
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			PostingHandler ph = new PostingHandler();
			introspector.bind(ph, bus);
			
			RemoveHandler rh = new RemoveHandler();
			introspector.bind(rh, bus);			
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\RemoveHandlers_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
				
				takeSnapshot(bus, "snapshots\\RemoveHandlers_"+obf.id+".dot");
			}			
						
			Handle<Object, Integer, Object, Long> wHandle = bus.post("World");
			bus.join();
			
			assertEquals(1, ph.getWorldCounter());
			assertTrue(ph.isWorldOk());
			
			assertEquals(1, ph.getEmCounter());
			assertTrue(ph.isEmOk());
			
			assertEquals(0, rh.getWorldCounter());			
			assertEquals(0, rh.getEmCounter());
			
			Set<String> expected = new HashSet<String>();
			expected.add("Hello");
			expected.add("World");
			expected.add("!");
						
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				if (!expected.remove(h.getEvent())) {
					fail("Unexpected object in the store: "+h.getEvent());
				}
			}
			
			if (!expected.isEmpty()) {
				fail("Not present in the store: "+expected);
			}
			
			wHandle.remove();
			bus.join();
			
			int counter=0;
			for (Handle<Object, Integer, Object, Long> h: bus.getStore()) {
				++counter;
				if (!"Bye!".equals(h.getEvent())) {
						fail("Unexpected object in the store: "+h.getEvent());
				}
			}				
			assertEquals(1, ph.getWorldCounter());
			assertTrue(ph.isWorldOk());
			
			assertEquals(1, ph.getEmCounter());
			assertTrue(ph.isEmOk());
			
			assertEquals(1, rh.getWorldCounter());			
			assertTrue(rh.isWorldOk());
			
			assertEquals(1, rh.getEmCounter());
			assertTrue(rh.isEmOk());
			
			assertEquals(String.valueOf(obf), 1, counter);		
		}
	}
	
	/**
	 * - Post 1st event, validate not fired
	 * - Post 2nd event, validate not fired
	 * - Remove 2nd event, validate fired
	 * - Remove 1st event, validate not fired 
	 * @throws Exception
	 */
	@Test
	public void testFireJoinRemoveHandler() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();			
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			JoinRemoveHandler jrh = new JoinRemoveHandler();
			introspector.bind(jrh, bus);
			
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\JoinRemoveHandler_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
				
				takeSnapshot(bus, "snapshots\\JoinRemoveHandler_"+obf.id+".dot");
			}			
						
			bus.post("World");
			bus.join();
			
			assertEquals(0, jrh.getJoinCounter());
			
			bus.post("Hello");
			bus.join();
			
			assertEquals(0, jrh.getJoinCounter());
			
			bus.remove("Hello");
			bus.join();
			
			assertEquals(1, jrh.getJoinCounter());
			assertTrue(jrh.isJoinOk());
			
			bus.remove("World");
			bus.join();
			
			assertEquals(1, jrh.getJoinCounter());
			assertTrue(jrh.isJoinOk());			
		}
	}
	
	/**
	 * - Post event which matcher remove handler 1
	 * - Update event with value which matches remove handler 2
	 * - Verify that remove handler 1 is fired
	 * - Remove event
	 * - Verify that remove handler 2 is fired
	 * @throws Exception
	 */
	@Test
	public void testUpdateFireRemoveHandlers() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			if (obf.pkStore) {
				continue; // No PK stores - events are mutable.
			}
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			RemoveHandler2 rh = new RemoveHandler2();
			introspector.bind(rh, bus);
			
			HelperHandler hh = new HelperHandler();
			introspector.bind(hh, bus);
			
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\RemoveHandler2_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
				
				takeSnapshot(bus, "snapshots\\RemoveHandler2_"+obf.id+".dot");
			}			
			
			AtomicReference<String> aRef = new AtomicReference<String>("World");
			
			rh.setExpectedWorld(aRef);
						
			Handle<Object, Integer, Object, Long> h = bus.post(aRef);
			bus.join();
			
			assertEquals(0, rh.getWorldCounter());
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(0, hh.getEmCounter());
			
			aRef.set("!");
			bus.join();
			assertEquals(0, rh.getWorldCounter());
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(0, hh.getEmCounter());
			
			h.update();
			bus.join();
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(String.valueOf(obf), 1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
			h.remove();
			bus.join();
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(1, rh.getEmCounter());
			assertTrue(rh.isEmOk());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
		}
	}
	
	/**
	 * Update event through dispatch context. Verify that remove
	 * handlers for old value are fired and that post handlers for 
	 * new value are fired. Use join handler or AFTER_EVENT policy.
	 * @throws Exception
	 */
	@Test
	public void testUpdateFromHandler() throws Exception {
		for (ObjectBusFactory obf: createObjectBus(null)) {
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			if (obf.pkStore) {
				continue; // No PK stores - events are mutable.
			}
			
			if (obf.getInferencePolicy() == InferencePolicy.IMMEDIATELY) {
				continue;
			}
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			RemoveHandler2 rh = new RemoveHandler2();
			introspector.bind(rh, bus);
			
			HelperHandler2 hh = new HelperHandler2();
			introspector.bind(hh, bus);
			
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\RemoveHandler2_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
				
				takeSnapshot(bus, "snapshots\\RemoveHandler2_"+obf.id+".dot");
			}			
			
			AtomicReference<String> aRef = new AtomicReference<String>("World");
			
			rh.setExpectedWorld(aRef);
						
			Handle<Object, Integer, Object, Long> h = bus.post(aRef);
			bus.join();
			
			assertEquals(0, rh.getWorldCounter());
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(0, hh.getEmCounter());
						
			bus.post("Hello"); // Hello fires join handler with World, which updates World to !
			bus.join();
			assertEquals(1, hh.getJoinCounter());
			assertTrue(hh.isJoinOk());
			
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(String.valueOf(obf), 1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
			h.remove();
			bus.join();
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(1, rh.getEmCounter());
			assertTrue(rh.isEmOk());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
		}
	}
	
	public static class ObservableStringReference implements Observable<ObservableStringReference> {
		
		public ObservableStringReference(String value) {
			super();
			this.value = value;
		}

		private Collection<Observer<? super ObservableStringReference>> observers = new ArrayList<Observer<? super ObservableStringReference>>();

		@Override
		public synchronized void addObserver(Observer<? super ObservableStringReference> o) {					
			observers.add(o);
		}

		@Override
		public synchronized void deleteObserver(Observer<? super ObservableStringReference> o) {
			observers.remove(o);
		}
		
		public Collection<Observer<? super ObservableStringReference>> getObservers() {
			return observers;
		}
		
		private volatile String value;
		
		public synchronized void set(String value) {
			this.value = value;
			for (Observer<? super ObservableStringReference> o: observers) {
				o.update(this);
			}
		}
		
		public String get() {
			return value;
		}

		
	};
	
	/**
	 * - Post event which matches handler 1, verify fired
	 * - Update event to match handler 2, verify that handler 2 is fired
	 * @throws Exception
	 */
	@Test
	public void testUpdateThroughObservable() throws Exception {
		ObservableConverter<Object> observableConverter = new ObservableConverter<Object>() {

			@Override
			public Observable<Object> convert(Object obj) {
				return obj instanceof Observable ? (Observable<Object>) obj : null;
			}
			
		}; 
		for (ObjectBusFactory obf: createObjectBus(null)) {
			obf.setObservableConverter(observableConverter);
			LocalEventBus<Object, Integer, Object> bus = obf.createBus();
			if (obf.pkStore) {
				continue; // No PK stores - events are mutable.
			}
			
			LocalIntrospector<Object, Object> introspector = new LocalIntrospector<Object, Object>(null, null);
			
			RemoveHandler2o rh = new RemoveHandler2o();
			introspector.bind(rh, bus);
			
			HelperHandler_o hh = new HelperHandler_o();
			introspector.bind(hh, bus);
			
			if (!obf.useSimpleMatcher) {
				SnapshotOutput emfSnapshot = new SnapshotOutput(new File("snapshots\\UpdateThroughObservable_"+obf.id+".snapshot"));
				bus.takeSnapshot(emfSnapshot);
				
				takeSnapshot(bus, "snapshots\\UpdateThroughObservable_"+obf.id+".dot");
			}			
			
			ObservableStringReference aRef = new ObservableStringReference("World");
			
			rh.setExpectedWorld(aRef);
			
			assertTrue(aRef.getObservers().isEmpty());
						
			Handle<Object, Integer, Object, Long> h = bus.post(aRef);
			bus.join();
			
			assertEquals(1, aRef.getObservers().size());
			
			assertEquals(0, rh.getWorldCounter());
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(0, hh.getEmCounter());
			
			aRef.set("!");
			bus.join();
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(0, rh.getEmCounter());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(String.valueOf(obf), 1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
			h.remove();
			bus.join();
			assertEquals(1, rh.getWorldCounter());
			assertTrue(rh.isWorldOk());			
			assertEquals(1, rh.getEmCounter());
			assertTrue(rh.isEmOk());
			
			assertEquals(1, hh.getWorldCounter());
			assertTrue(hh.isWorldOk());
			
			assertEquals(1, hh.getEmCounter());
			assertTrue(hh.isEmOk());
			
			assertTrue(aRef.getObservers().isEmpty());
			
		}
	}
					
}
