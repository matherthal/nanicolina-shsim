package com.hammurapi.eventbus.tests;

import java.util.concurrent.atomic.AtomicReference;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.local.LocalEventDispatchJoinContext;

public class HelperHandler2 {
	
	private int worldCounter;
	private boolean worldOk;
	
	private int emCounter;
	private boolean emOk;
	
	public int getWorldCounter() {
		return worldCounter;
	}

	public boolean isWorldOk() {
		return worldOk;
	}

	public int getEmCounter() {
		return emCounter;
	}

	public boolean isEmOk() {
		return emOk;
	}

	@Handler("java(str)://str.get().equals(\"World\")")
	public void handleWorld(AtomicReference<String> strRef) {
		++worldCounter;
		worldOk = "World".equals(strRef.get());
	}
	
	@Handler //("\"!\".equals(args[0])")
	public void handleEm(@Condition("\"!\".equals(strRef.get())") AtomicReference<String> strRef) {
		++emCounter;
		emOk = "!".equals(strRef.get());
	}
	
	private int joinCounter;
	private boolean joinOk;	
	
	public boolean isJoinOk() {
		return joinOk;
	}
	
	public int getJoinCounter() {
		return joinCounter;
	}

	/**
	 * Updates world to ! when Hello is posted.
	 * @param context
	 * @param hello
	 * @param worldRef
	 * @param i
	 */
	@Handler("worldRef.get().equals(\"World\")")
	public void join(
			LocalEventDispatchJoinContext<Object, Integer, Object> context, 
			@Condition("\"Hello\".equals(hello)") String hello, 
			AtomicReference<String> worldRef) {
		++joinCounter;
		joinOk = "Hello".equals(hello) && "World".equals(worldRef.get());
		
		worldRef.set("!");
		context.update(worldRef);
	}
}
