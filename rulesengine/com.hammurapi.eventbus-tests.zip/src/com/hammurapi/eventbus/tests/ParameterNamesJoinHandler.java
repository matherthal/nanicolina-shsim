package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;

public class ParameterNamesJoinHandler {
	
	private int helloCounter;
	private boolean helloOk;
	
	public int getHelloCounter() {
		return helloCounter;
	}

	public boolean isHelloOk() {
		return helloOk;
	}
	
	private int joinCounter;
	private boolean joinOk;	
	
	public boolean isJoinOk() {
		return joinOk;
	}
	
	public int getJoinCounter() {
		return joinCounter;
	}

	@Handler("java(*)://str.equals(\"Hello\")")
	public String handleHello(String str) {
		++helloCounter;
		helloOk = "Hello".equals(str);
		return "World";
	}
	
	@Handler({
			"java(*)://world.equals(\"World\")",
			"java(*)://AND(i+((int) 'A')> (int) hello.charAt(0),i+((int) 'A')< (int) world.charAt(0))"
		})
	public void join(
			LocalEventDispatchContext<Object, Integer, Object> context, 
			@Condition("\"Hello\".equals(hello)") String hello, 
			String world, 
			int i) {
		++joinCounter;
		joinOk = "Hello".equals(hello) && "World".equals(world) && i>'H'-'A' && i<'W'-'A';
	}
}
