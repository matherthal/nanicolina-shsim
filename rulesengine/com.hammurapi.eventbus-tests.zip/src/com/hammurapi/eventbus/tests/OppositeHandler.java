package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;

public class OppositeHandler {
	
	private boolean oneInvoked;
	private boolean twoInvoked;
		
	@Handler
	public void handleOne(@Condition("java(*)://str.length()==10 && str.startsWith(\"Hello\")") String str) {
		oneInvoked = true;
	}
	
	@Handler("java(*)://AND(s.endsWith(\"world!\"), 10!=s.length())")
	public void handleTwo(String s) {
		twoInvoked = true;
	}
	
	@Handler("java(*)://i>118") 
	public void handleInteger(Integer i) {
		
	}

	public boolean isOneInvoked() {
		return oneInvoked;
	}
	
	public boolean isTwoInvoked() {
		return twoInvoked;
	}
	
}
