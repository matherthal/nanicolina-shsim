package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class TokenParameterizedStringHandlerWithMethodCondition {
	
	private int counter;
	private boolean ok;

	public int getCounter() {
		return counter;
	}
	
	public boolean isOk() {
		return ok;
	}
	
	@Handler("java(str)://str.equals(${filterStr|\"zz\"})")
	public void handle(String str) {
		++counter;
		ok = "Hello".equals(str);
	}
}
