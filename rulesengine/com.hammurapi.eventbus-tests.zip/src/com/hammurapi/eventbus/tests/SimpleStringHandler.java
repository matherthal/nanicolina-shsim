package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class SimpleStringHandler {
	
	private volatile int counter;
	
	public int getCounter() {
		return counter;
	}
	
	@Handler
	public void handle(String str) {
		++counter;
	}
	
}
