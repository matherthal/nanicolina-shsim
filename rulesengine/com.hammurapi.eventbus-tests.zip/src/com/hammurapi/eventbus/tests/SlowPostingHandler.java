package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;

public class SlowPostingHandler {
	
	private volatile int counter;
	
	@Handler("java(str)://str.equals(\"World\")")
	public String handleWorld(String str) throws InterruptedException {
		Thread.sleep(50);
		++counter;
		return "!";
	}
	
	@Handler
	public void handleEm(LocalEventDispatchContext<Object, Integer, Object> context, @Condition("\"!\".equals(str)") String str) throws InterruptedException {
		Thread.sleep(100);
		++counter;
		context.post("Hello");
	}
	
	public int getCounter() {
		return counter;
	}
}
