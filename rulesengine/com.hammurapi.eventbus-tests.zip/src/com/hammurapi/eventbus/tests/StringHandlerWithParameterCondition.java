package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;

public class StringHandlerWithParameterCondition {
	
	private int counter;
	private boolean ok;

	public int getCounter() {
		return counter;
	}
	
	public boolean isOk() {
		return ok;
	}
	
	@Handler
	public void handle(@Condition("\"Hello\".equals(str)") String str) {
		++counter;
		ok = "Hello".equals(str);
	}
	
}
