package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class ParameterizedStringHandlerWithMethodCondition {
	
	private int counter;
	private boolean ok;

	public int getCounter() {
		return counter;
	}
	
	public boolean isOk() {
		return ok;
	}
	
	@Handler("java(str)://str.equals(eCtx.getFilterStr())")
	public void handle(String str) {
		++counter;
		ok = "Hello".equals(str);
	}
	
	private String filterStr;
	
	public String getFilterStr() {
		return filterStr;
	}
	
	public void setFilterStr(String filterStr) {
		this.filterStr = filterStr;
	}
	
}
