package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class InfiniteHandler {
	
	private volatile int counter;

	public int getCounter() {
		return counter;
	}
	
	@Handler
	public String handle(String str) {
		++counter;
		return str+"A";
	}
	
}
