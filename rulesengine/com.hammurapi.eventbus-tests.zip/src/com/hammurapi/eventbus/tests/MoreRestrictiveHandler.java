package com.hammurapi.eventbus.tests;

import java.util.Collection;
import java.util.List;

import com.hammurapi.eventbus.Handler;

public class MoreRestrictiveHandler {
	
	private boolean listInvoked;
	private boolean handleInvoked;
		
	@Handler
	public void handleList(List<?> list) {
		listInvoked = true;
	}
	
	@Handler
	public void handleCollection(Collection<?> collection) {
		handleInvoked = true;
	}

	public boolean isListInvoked() {
		return listInvoked;
	}
	
	public boolean isCollectionInvoked() {
		return handleInvoked;
	}
	
}
