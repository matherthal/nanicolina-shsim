package com.hammurapi.eventbus.tests;

import java.util.concurrent.atomic.AtomicInteger;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;

public class PriorityHandler {
	
	private AtomicInteger hpCounter = new AtomicInteger();
	private AtomicInteger ahpCounter = new AtomicInteger();
	private AtomicInteger lpCounter = new AtomicInteger();
	
	@Handler(priority=10)
	public void highPriority(LocalEventDispatchContext<Object, Integer, Object> ctx, String event) throws InterruptedException {
		hpCounter.incrementAndGet();
		Thread.sleep(500);
		if ("Hello".equals(event)) {
			ctx.consume(event);
		}
	}
	
	@Handler(priority=11)
	public void anotherHighPriority(String event) {
		ahpCounter.incrementAndGet();
	}
	
	@Handler
	public void lowPriority(String event) {
		lpCounter.incrementAndGet();
	}
	
	public int getHpCounter() {
		return hpCounter.get();
	}
	
	public int getAhpCounter() {
		return ahpCounter.get();
	}
	
	public int getLpCounter() {
		return lpCounter.get();
	}
}
