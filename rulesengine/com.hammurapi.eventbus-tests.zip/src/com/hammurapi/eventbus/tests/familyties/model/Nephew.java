/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Nephew extends Relative {

	public Nephew(Person subject, Person object) {
		super(subject, object);
	}

}
