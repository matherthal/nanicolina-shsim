/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Mother extends Parent {

	public Mother(Person subject, Person object) {
		super(subject, object);
	}

}
