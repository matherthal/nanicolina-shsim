package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.EventDispatchJoinContext;

/**
 * Event dispatch join context with partially bound generic parameters.
 * @author Pavel Vlasov
 *
 * @param <E>
 * @param <P>
 * @param <C>
 */
public interface FamilyTiesEventDispatchJoinContext extends FamilyTiesEventDispatchContext, EventDispatchJoinContext<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> {

}
