/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Parent;

public class ParentChildRules extends FamilyTiesRules {
	
	/**
	 * Infers child relaitonship from parent relationship.
	 * @param parent
	 * @return
	 */
	@Handler	
	public Child infer(Parent parent) {
		return new Child(parent.getObject(), parent.getSubject()); 
	}
	
	/**
	 * Infers parent relationship from child relationship
	 * @param child
	 * @return
	 */
	@Handler	
	public Parent infer(Child child) {
		return new Parent(child.getObject(), child.getSubject()); 
	}
	
}
