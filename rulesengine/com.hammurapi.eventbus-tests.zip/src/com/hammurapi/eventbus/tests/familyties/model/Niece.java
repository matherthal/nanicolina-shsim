/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Niece extends Relative {

	public Niece(Person subject, Person object) {
		super(subject, object);
	}

}
