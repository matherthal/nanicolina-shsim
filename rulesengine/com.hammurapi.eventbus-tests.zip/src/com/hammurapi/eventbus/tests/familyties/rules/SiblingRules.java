/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesEventDispatchContext;
import com.hammurapi.eventbus.tests.familyties.model.Brother;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Sibling;
import com.hammurapi.eventbus.tests.familyties.model.Sister;

public class SiblingRules extends FamilyTiesRules {	
	
	/**
	 * Male sibling is brother, female sibling is sister.
	 * If A is a sibling of B then B is a sibling of A.
	 * @param sibling
	 * @return Brother or Sister.
	 */
	@Handler(posts={Sibling.class, Brother.class, Sister.class})
	public Sibling infer(FamilyTiesEventDispatchContext dispatchContext, Sibling sibling) {	
		dispatchContext.post(new Sibling(sibling.getObject(), sibling.getSubject()));
		
		if (sibling.getSubject().isMale()) {
			if (!(sibling instanceof Brother)) {
				return new  Brother(sibling.getSubject(), sibling.getObject());
			}			
		} else {
			if (!(sibling instanceof Sister)) {
				return new Sister(sibling.getSubject(), sibling.getObject());
			}			
		}
		return null;
	}

	/**
	 * If two children have common parent then they are siblings.
	 * @param child
	 * @param anotherChild
	 */
	@Handler(value="java(*)://!child.getSubject().equals(anotherChild.getSubject()) && child.getObject().equals(anotherChild.getObject())",	posts=Sibling.class)
	public void infer(FamilyTiesEventDispatchContext dispatchContext, Child child, Child anotherChild) {
		dispatchContext.post(new Sibling(child.getSubject(), anotherChild.getSubject()));
		dispatchContext.post(new Sibling(anotherChild.getSubject(), child.getSubject()));
	}
}
