package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.extract.Predicate;

/**
 * Domain-specific event store predicate interface.
 *
 */
public interface FamilyTiesEventStorePredicate extends Predicate<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> {

}
