package com.hammurapi.eventbus.tests.familyties;

import java.util.concurrent.TimeUnit;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.extract.AbstractPredicate;

/**
 * Domain-specific event store predicate interface.
 *
 */
public abstract class FamilyTiesEventStoreAbstractPredicate extends AbstractPredicate<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> implements FamilyTiesEventStorePredicate {

	public FamilyTiesEventStoreAbstractPredicate(
			double initialCost,
			TimeUnit costUnit, 
			boolean contextDependent) {
		
		super(initialCost, costUnit, contextDependent, 0);
	}

}
