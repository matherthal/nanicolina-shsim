package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.EventStore;
import com.hammurapi.eventbus.tests.familyties.model.Person;
import com.hammurapi.eventbus.tests.familyties.model.Relative;

/**
 * Domain-specific event store
 */
public interface FamilyTiesEventStore extends EventStore<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> {

	Iterable<Relative> getRelatives(Person subject);
}

