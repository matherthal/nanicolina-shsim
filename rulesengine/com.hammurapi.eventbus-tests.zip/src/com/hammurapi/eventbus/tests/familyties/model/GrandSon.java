/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class GrandSon extends GrandChild {

	public GrandSon(Person subject, Person object) {
		super(subject, object);
	}

}
