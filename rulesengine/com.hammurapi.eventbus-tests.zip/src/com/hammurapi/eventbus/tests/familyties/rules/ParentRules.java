/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Father;
import com.hammurapi.eventbus.tests.familyties.model.Mother;
import com.hammurapi.eventbus.tests.familyties.model.Parent;

public class ParentRules extends FamilyTiesRules {	
	
	/**
	 * Male parent is father, female parent is mother.
	 * @param parent
	 * @return Brother or Sister.
	 */
	@Handler(posts={Father.class, Mother.class})
	public Parent infer(Parent parent) {	
		
		if (parent.getSubject().isMale()) {
			if (!(parent instanceof Father)) {
				return new  Father(parent.getSubject(), parent.getObject());
			}			
		} else {
			if (!(parent instanceof Mother)) {
				return new Mother(parent.getSubject(), parent.getObject());
			}			
		}
		return null;
	}
}
