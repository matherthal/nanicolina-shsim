/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Son extends Child {

	public Son(Person subject, Person object) {
		super(subject, object);
	}

}
