/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Daughter;

public class DaughterRule extends FamilyTiesRules {
	
	@Handler	
	public Daughter infer(
			@Condition("!(child instanceof com.hammurapi.eventbus.tests.familyties.model.Daughter) && !child.getSubject().isMale()") Child child
	) {
		return new Daughter(child.getSubject(), child.getObject());
	}
}
