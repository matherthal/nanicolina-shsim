/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.FamilyTiesEventDispatchContext;
import com.hammurapi.eventbus.tests.familyties.model.Aunt;
import com.hammurapi.eventbus.tests.familyties.model.Brother;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Cousin;
import com.hammurapi.eventbus.tests.familyties.model.Daughter;
import com.hammurapi.eventbus.tests.familyties.model.Husband;
import com.hammurapi.eventbus.tests.familyties.model.Nephew;
import com.hammurapi.eventbus.tests.familyties.model.Niece;
import com.hammurapi.eventbus.tests.familyties.model.Parent;
import com.hammurapi.eventbus.tests.familyties.model.Sibling;
import com.hammurapi.eventbus.tests.familyties.model.Sister;
import com.hammurapi.eventbus.tests.familyties.model.Son;
import com.hammurapi.eventbus.tests.familyties.model.Uncle;
import com.hammurapi.eventbus.tests.familyties.model.Wife;

/**
 * Infers aunt, uncle, cousin, niece, nephew
 * @author Pavel Vlasov
 * @revision $Revision$
 */
public class SecondaryRules extends FamilyTiesRules {
	
	/**
	 * Infers cousin as a child or parent's sibling.
	 */
	@Handler(posts=Cousin.class)
	public void infer(FamilyTiesEventDispatchContext dispatchContext, Child child1, Child child2, Sibling sibling) {
		if (child1.getObject().equals(sibling.getSubject()) && child2.getObject().equals(sibling.getObject())) {
			dispatchContext.post(new Cousin(child1.getSubject(), child2.getSubject()));
		}
	}
	
	/**
	 * If A is a cousin of B then B is a cousin of A
	 * @param cousin
	 * @return
	 */
	@Handler	
	public Cousin infer(Cousin cousin) {
		return new Cousin(cousin.getObject(), cousin.getSubject());
	}
	
	/**
	 * Another way to infer cousin to demonstrate mutiple derivations
	 * @param aunt
	 * @param child
	 */
	@Handler("aunt.getSubject().equals(parent.getSubject())")
//	@Handler("args[0].getSubject().equals(args[1].getSubject())")
	public Cousin infer(Aunt aunt, Parent parent) {
		return new Cousin(aunt.getObject(), parent.getObject());
	}
	
	/**
	 * Another way to infer cousin to demonstrate mutiple derivations
	 * @param uncle
	 * @param child
	 */
	@Handler	
	public Cousin infer(Uncle uncle, Parent parent) {
		if (uncle.getSubject().equals(parent.getSubject())) {
			return new Cousin(uncle.getObject(), parent.getObject());
		}
		return null;
	}
	
	/**
	 * Sister of parent is aunt.
	 * @param sister
	 * @param parent
	 */
	@Handler	
	public Aunt infer(Sister sister, Parent parent) {
		return sister.getObject().equals(parent.getSubject()) ? new Aunt(sister.getSubject(), parent.getObject()) : null;
	}
	
	/**
	 * Wife of uncle is aunt.
	 * @param sister
	 * @param parent
	 */
	@Handler	
	public Aunt infer(Wife wife, Uncle uncle) {
		return wife.getObject().equals(uncle.getSubject()) ? new Aunt(wife.getSubject(), uncle.getObject()) : null;
	}
	
	/**
	 * Brother of parent is uncle.
	 * @param sister
	 * @param parent
	 */
	@Handler	
	public Uncle infer(Brother brother, Parent parent) {
		return brother.getObject().equals(parent.getSubject()) ? new Uncle(brother.getSubject(), parent.getObject()) : null;
	}
	
	/**
	 * Husband of aunt is uncle.
	 * @param sister
	 * @param parent
	 */
	@Handler	
	public Uncle infer(Husband husband, Aunt aunt) {
		return husband.getObject().equals(aunt.getSubject()) ? new Uncle(husband.getSubject(), aunt.getObject()) : null;
	}
	
	/**
	 * Daughter of sibling is niece.
	 */
	@Handler("java(daughter, sibling)://daughter.getObject().equals(sibling.getSubject())")	
	public Niece infer(Daughter daughter, Sibling sibling) {
		return new Niece(daughter.getSubject(), sibling.getObject());
	}
	
	// TODO Implement: Spouse's niece is my niece.
	
	/**
	 * Son of sibling is nephew.
	 */
	@Handler("java(son,sibling)://son.getObject().equals(sibling.getSubject())")	
	public Nephew infer(Son son, Sibling sibling) {
		return new Nephew(son.getSubject(), sibling.getObject());
	}
	
	// TODO Implement: Spouse's nephew is my nephew.
		
}
