/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Person implements Comparable<Person> {

	private String name;

	private boolean isMale;
	
	private int age;

	public Person(String name, int age, boolean isMale) {
		super();
		this.name = name;
		this.age = age;
		this.isMale = isMale;
	}

	public String toString() {
		return name + " ["+(isMale ? "male " : "female ")+age+" "+identity()+"]";
	}

	private String identity() {
		return ""; //Integer.toString(System.identityHashCode(this), Character.MAX_RADIX);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + (isMale ? 1231 : 1237);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Person other = (Person) obj;
		if (age != other.age) {
			return false;
		}
		if (isMale != other.isMale) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

	public boolean isMale() {
		return isMale;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public int compareTo(Person o) {
		if (this==o || this.equals(o)) {
			return 0;
		}
		
		int nameCompare = getName().compareTo(o.getName());
		if (nameCompare!=0) {
			return nameCompare;
		}
		
		int ageCompare = getAge() - o.getAge();
		
		if (ageCompare!=0) {
			return ageCompare;
		}
				
		if (isMale()) {
			if (!o.isMale()) {
				return -1;
			}
		} else {
			if (o.isMale()) {
				return 1;
			}
		}
		return hashCode()- o.hashCode();
	}

	
}
