package com.hammurapi.eventbus.tests.familyties.rules;

/**
 * Base class for family ties rule classes. 
 * @author Pavel Vlasov
 *
 */
public class FamilyTiesRules {

}
