package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.convert.AbstractReflectiveAtomicConvertersBundle;
import com.hammurapi.convert.Converter;
import com.hammurapi.convert.ConverterMethod;
import com.hammurapi.eventbus.snapshot.CompositeEvent;
import com.hammurapi.eventbus.snapshot.Event;
import com.hammurapi.eventbus.snapshot.SnapshotFactory;
import com.hammurapi.eventbus.tests.familyties.model.Person;
import com.hammurapi.eventbus.tests.familyties.model.Relative;

public class FamilyTiesConvertersBundle extends AbstractReflectiveAtomicConvertersBundle {
	
	/**
	 * Converter method for relative. 
	 * @param relative
	 * @return
	 */
	@ConverterMethod
	public CompositeEvent convertToEvent(Relative relative, Converter master) {
		CompositeEvent ce = SnapshotFactory.eINSTANCE.createCompositeEvent();
		int idx = relative.getClass().getName().lastIndexOf('.');
		ce.setName(relative.getClass().getName().substring(idx+1));
		ce.setDetails(relative.toString());
		
		Event subj = master.convert(relative.getSubject(), Event.class, null);
		subj.setPartRole("subject");
		subj.setId("");
		ce.getParts().add(subj);
		
		Event obj = master.convert(relative.getObject(), Event.class, null);
		obj.setPartRole("object");
		obj.setId("");
		ce.getParts().add(obj);
		
		return ce;
	}
	
	@ConverterMethod
	public Event convertToEvent(Person person) {
		Event ret = SnapshotFactory.eINSTANCE.createEvent();
		ret.setName(person.getName());
		ret.setDetails(person.toString());
		return ret;
	}
}
