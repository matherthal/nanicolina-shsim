/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Son;

public class SonRule extends FamilyTiesRules {
	
	@Handler(posts=Son.class)
	public Son infer(@Condition("java(child)://!(child instanceof com.hammurapi.eventbus.tests.familyties.model.Son) && child.getSubject().isMale()") Child child) {
		return new Son(child.getSubject(), child.getObject());
	}
}
