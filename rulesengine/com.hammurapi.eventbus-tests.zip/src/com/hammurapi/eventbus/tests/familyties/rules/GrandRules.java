/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Daughter;
import com.hammurapi.eventbus.tests.familyties.model.Father;
import com.hammurapi.eventbus.tests.familyties.model.GrandDaughter;
import com.hammurapi.eventbus.tests.familyties.model.GrandFather;
import com.hammurapi.eventbus.tests.familyties.model.GrandMother;
import com.hammurapi.eventbus.tests.familyties.model.GrandSon;
import com.hammurapi.eventbus.tests.familyties.model.Mother;
import com.hammurapi.eventbus.tests.familyties.model.Parent;
import com.hammurapi.eventbus.tests.familyties.model.Son;

public class GrandRules extends FamilyTiesRules {
		
	/**
	 * Son of child is a grandson.
	 * @param son
	 * @param parent
	 * @return
	 */
	@Handler("java(*):// son.getObject().equals(parent.getObject())")
	public GrandSon infer(Son son, Parent parent) {
		return new GrandSon(son.getSubject(), parent.getSubject());
	}
	
	/**
	 * Daughter of child is a granddaughter.
	 * @param daughter
	 * @param parent
	 * @return
	 */
	@Handler("java(*):// daughter.getObject().equals(parent.getObject())")
	public GrandDaughter infer(Daughter daughter, Parent parent) {
		return new GrandDaughter(daughter.getSubject(), parent.getSubject()); 
	}
	
	/**
	 * Father of parent is grandparent.
	 * @param child
	 * @param father
	 * @return
	 */
	@Handler("java(*)://child.getObject().equals(father.getObject())")
	public GrandFather infer(Child child, Father father) {
		return new GrandFather(father.getSubject(), child.getSubject());
	}
	
	/**
	 * Mother of parent is grandmother.
	 * @param child
	 * @param mother
	 * @return
	 */
	@Handler("java(child, mother)://child.getObject().equals(mother.getObject())")
	public GrandMother infer(Child child, Mother mother) {
		return new GrandMother(mother.getSubject(), child.getSubject());
	}
	
}
