/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Husband extends Spouse {

	public Husband(Person subject, Person object) {
		super(subject, object);
	}

}
