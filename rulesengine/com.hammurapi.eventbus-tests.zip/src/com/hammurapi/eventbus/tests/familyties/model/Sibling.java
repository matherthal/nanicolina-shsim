/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Sibling extends CloseRelative {

	public Sibling(Person subject, Person object) {
		super(subject, object);
	}

}
