package com.hammurapi.eventbus.tests.familyties;

import java.util.concurrent.TimeUnit;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.extract.AbstractExtractor;

/**
 * Domain-specific event store predicate interface.
 *
 */
public abstract class FamilyTiesEventStoreAbstractExtractor<V> extends AbstractExtractor<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, V, FamilyTiesEventStore> implements FamilyTiesEventStoreExtractor<V> {

	public FamilyTiesEventStoreAbstractExtractor(
			double initialCost,
			TimeUnit costUnit, 
			boolean contextDependent) {
		
		super(initialCost, costUnit, contextDependent, 0);
	}

}
