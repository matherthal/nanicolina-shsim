package com.hammurapi.eventbus.tests.familyties;


/**
 * Generated domain-specific event bus.
 */
public class FamilyTiesEventBus extends com.hammurapi.eventbus.local.LocalEventBusBase<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,FamilyTiesEventStore> {

	public FamilyTiesEventBus(Config config) {
		super(config);
	}

	/**
	 * Event bus configurator.
	 */
	public static class Config extends com.hammurapi.eventbus.local.LocalEventBusBase.Config<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, FamilyTiesEventStore> {
		
		public Config() {
			setEventType(com.hammurapi.eventbus.tests.familyties.model.Relative.class);
		}
	}


}
