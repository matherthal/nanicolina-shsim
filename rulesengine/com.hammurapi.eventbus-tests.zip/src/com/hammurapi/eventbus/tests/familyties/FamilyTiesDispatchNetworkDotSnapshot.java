package com.hammurapi.eventbus.tests.familyties;

import java.io.File;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.DispatchNetworkDotSnapshot;

public class FamilyTiesDispatchNetworkDotSnapshot extends DispatchNetworkDotSnapshot<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long, AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long>, FamilyTiesEventStore> {

	public FamilyTiesDispatchNetworkDotSnapshot(File out) {
		super(out);
	}

}
