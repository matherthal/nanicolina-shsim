package com.hammurapi.eventbus.tests.familyties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.HandleExtractor;
import com.hammurapi.eventbus.tests.familyties.model.Person;
import com.hammurapi.eventbus.tests.familyties.model.Relative;
import com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules;
import com.hammurapi.extract.Extractor;
import com.hammurapi.extract.Predicate;
import com.hammurapi.store.AbstractStore;
import com.hammurapi.store.DeputyStore;
import com.hammurapi.store.Index;
import com.hammurapi.store.LiveView;
import com.hammurapi.store.MultiIndex;
import com.hammurapi.store.UnmodifiableStore;
import com.hammurapi.store.local.LocalStoreBase;

/**
 * Implementation of event store.
 * @author Pavel Vlasov
 *
 * @param <E>
 * @param <P>
 * @param <C>
 */
public class FamilyTiesEventStoreImpl extends LocalStoreBase<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> implements FamilyTiesEventStore {

	/**
	 * Config class with bound generic parameters. 
	 * @author Pavel Vlasov
	 *
	 */
	public static class Config extends LocalStoreBase.Config<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> {
		
		public Config() {
			setPrimaryKeyExtractor(new HandleExtractor<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long, AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore>());
		}
	}

	private MultiIndex<AbstractEventBus.Handle<Relative, Integer, FamilyTiesRules, Long>, Relative, Person, FamilyTiesEventStore> subjectIndex;

	public FamilyTiesEventStoreImpl(Config config) {
		super(config);
		
		FamilyTiesEventStoreExtractor<Person> subjectExtractor = new FamilyTiesEventStoreAbstractExtractor<Person>(0, null, false) {

			@Override
			protected Person extractInternal(
					FamilyTiesEventStore context,
					Map<FamilyTiesEventStore, Map<Extractor<com.hammurapi.eventbus.AbstractEventBus.Handle<Relative, Integer, FamilyTiesRules, Long>, ? super Person, FamilyTiesEventStore>, ? super Person>> cache,
					com.hammurapi.eventbus.AbstractEventBus.Handle<Relative, Integer, FamilyTiesRules, Long>... obj) {
				
				return obj[0].getEvent().getSubject();
			}

		}; 
		subjectIndex = (MultiIndex<com.hammurapi.eventbus.AbstractEventBus.Handle<Relative, Integer, FamilyTiesRules, Long>, Relative, Person, FamilyTiesEventStore>) addIndex(null, subjectExtractor, Index.Type.LAZY, false, null); 
	}
	
	@Override
	public Iterable<Relative> getRelatives(Person subject) {
		Collection<Relative> ret = new ArrayList<Relative>();
		Z: for (AbstractEventBus.Handle<Relative, Integer, FamilyTiesRules, Long> h: subjectIndex.find(subject)) {
			if (h.isValid()) {
				Relative newRelative = h.getEvent();
				Iterator<Relative> rit = ret.iterator();
				while (rit.hasNext()) {
					Relative eRelative = rit.next();
					switch (supercedes(eRelative, newRelative)) {
					case 0:
						// Unrelated - go further.
						break;
					case 1:
						// No need to add this new relative, jump to next new relative
						continue Z;
					case -1:
						// New relative supercedes this one.
						rit.remove();
						break;
					}
				}
				ret.add(newRelative);
			}
		}
		return ret;
	}
	
	/**
	 * 
	 * @param r0
	 * @param r1
	 * @return -1 - r1 is more specific (e.g. Daughter instead of Child) than r0, 0 - unrelated, 1 - r0 is more specific or equal. 
	 */
	private int supercedes(Relative r0, Relative r1) {
		if (r0.equals(r1)) {
			return 1;
		}
		if (r0.getSubject().equals(r1.getSubject()) && r0.getObject().equals(r1.getObject())) {
			if (r0.getClass().isInstance(r1)) { // r1 is more specific
				return -1;
			}
			
			if (r1.getClass().isInstance(r0)) { // r0 is more specific
				return 1;
			}
			
		}
		return 0;
	}
	
	protected static class FamilyTiesEventDeputyStore extends DeputyStore<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> implements FamilyTiesEventStore {

		public FamilyTiesEventDeputyStore(
				AbstractStore<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> master,
				ReadWriteLock masterLock) {
			super(master, masterLock);
		}

		@Override
		protected FamilyTiesEventStore createDeputy() {
			return new FamilyTiesEventDeputyStore(this, createMasterLock());
		}
		
		@Override
		public FamilyTiesEventStore createUnmodifiableFacade() {
			return new FamilyTiesEventUnmodifiableStore(this);
		}

		@Override
		protected FamilyTiesEventStore createLiveView(Predicate<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> selector) {
			return new FamilyTiesEventLiveView(this, selector);
		}
		
		@Override
		public Iterable<Relative> getRelatives(Person subject) {
			return ((FamilyTiesEventStore) master).getRelatives(subject);
		}
		
	}
	
	protected static class FamilyTiesEventUnmodifiableStore extends UnmodifiableStore<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> implements FamilyTiesEventStore {

		public FamilyTiesEventUnmodifiableStore(FamilyTiesEventStore master) {
			super(master);
		}
		
		@Override
		public Iterable<Relative> getRelatives(Person subject) {
			return ((FamilyTiesEventStore) master).getRelatives(subject);
		}
		
	}
	
	protected static class FamilyTiesEventLiveView extends LiveView<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, com.hammurapi.eventbus.tests.familyties.model.Relative, FamilyTiesEventStore> implements FamilyTiesEventStore {
		
		public FamilyTiesEventLiveView(
				FamilyTiesEventStore master,
				Predicate<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative, java.lang.Integer, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long>, FamilyTiesEventStore> selector) {
			super(master, selector);
		}

		@Override
		public FamilyTiesEventStore createUnmodifiableFacade() {
			return new FamilyTiesEventUnmodifiableStore(this);
		}
		
		@Override
		public Iterable<Relative> getRelatives(Person subject) {
			return ((FamilyTiesEventStore) master).getRelatives(subject);
		}
		
	}

	@Override
	protected FamilyTiesEventStore createDeputy() {
		return new FamilyTiesEventDeputyStore(this, createMasterLock());
	}
	
	@Override
	public FamilyTiesEventStore createUnmodifiableFacade() {
		return new FamilyTiesEventUnmodifiableStore(this);
	}

	@Override
	protected FamilyTiesEventStore createLiveView(Predicate<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore> selector) {
		return new FamilyTiesEventLiveView(this, selector);
	}

}
