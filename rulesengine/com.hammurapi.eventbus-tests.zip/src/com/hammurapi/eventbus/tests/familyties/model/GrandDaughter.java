/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class GrandDaughter extends GrandChild {

	public GrandDaughter(Person subject, Person object) {
		super(subject, object);
	}

}
