/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Father extends Parent {

	public Father(Person subject, Person object) {
		super(subject, object);
	}

}
