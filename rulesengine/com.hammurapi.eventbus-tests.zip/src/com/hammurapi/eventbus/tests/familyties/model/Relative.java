/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Relative implements Comparable<Relative> {
	
	private Person subject;
	private Person object;

	public Relative(Person subject, Person object) {
		this.subject = subject;
		this.object = object;
	}

	public String toString() {
		StringBuffer ret = new StringBuffer(getSubject().toString());
		ret.append(" is a ");
		
		int idx = getClass().getName().lastIndexOf('.');
		ret.append(idx == -1 ? getClass().getName() : getClass().getName().substring(idx + 1));
		ret.append(" of ");
		ret.append(getObject().toString());
		ret.append(" (");
//		ret.append(Integer.toString(System.identityHashCode(this), Character.MAX_RADIX));
		ret.append(")");
//		ret.append(" (");
//		ret.append(getDepth());
//		ret.append("/");
//		ret.append(getCardinality());
//		ret.append(")");
		return ret.toString();
	}
	
	public Person getSubject() {
		return subject;
	}
	
	public Person getObject() {
		return object;
	}
	
	public int compareTo(Relative o) {
		if (this==o || this.equals(o)) {
			return 0;
		}
		
		int subjectCompare = getSubject().compareTo(o.getSubject());
		if (subjectCompare!=0) {
			return subjectCompare;
		}
		
		int objectCompare = getObject().compareTo(o.getObject());
		if (objectCompare!=0) {
			return objectCompare;
		}
		
		int typeCompare = getClass().getName().compareTo(o.getClass().getName());
		if (typeCompare!=0) {
			return typeCompare;
		}
		
		return hashCode() - o.hashCode();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = getClass().hashCode();
		result = prime * result + ((object == null) ? 0 : object.hashCode());
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Relative other = (Relative) obj;
		if (object == null) {
			if (other.object != null) {
				return false;
			}
		} else if (!object.equals(other.object)) {
			return false;
		}
		if (subject == null) {
			if (other.subject != null) {
				return false;
			}
		} else if (!subject.equals(other.subject)) {
			return false;
		}
		return true;
	}	
	
}
