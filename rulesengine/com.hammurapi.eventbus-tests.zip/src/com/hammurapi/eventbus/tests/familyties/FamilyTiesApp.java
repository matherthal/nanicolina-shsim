package com.hammurapi.eventbus.tests.familyties;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.hammurapi.eventbus.InferencePolicy;
import com.hammurapi.eventbus.tests.familyties.model.Child;
import com.hammurapi.eventbus.tests.familyties.model.Person;
import com.hammurapi.eventbus.tests.familyties.model.Relative;
import com.hammurapi.eventbus.tests.familyties.model.Spouse;
import com.hammurapi.eventbus.tests.familyties.rules.DaughterRule;
import com.hammurapi.eventbus.tests.familyties.rules.DaughterRuleJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.GrandRules;
import com.hammurapi.eventbus.tests.familyties.rules.GrandRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.ParentChildRules;
import com.hammurapi.eventbus.tests.familyties.rules.ParentChildRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.ParentRules;
import com.hammurapi.eventbus.tests.familyties.rules.ParentRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SecondaryRules;
import com.hammurapi.eventbus.tests.familyties.rules.SecondaryRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SiblingRules;
import com.hammurapi.eventbus.tests.familyties.rules.SiblingRulesJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SonRule;
import com.hammurapi.eventbus.tests.familyties.rules.SonRuleJavaBinder;
import com.hammurapi.eventbus.tests.familyties.rules.SpouseRules;
import com.hammurapi.eventbus.tests.familyties.rules.SpouseRulesJavaBinder;

public class FamilyTiesApp {

	/**
	 * @param args
	 */
	public static String infer() throws Exception {
 		ExecutorService executorService = Executors.newFixedThreadPool(2);
 		
		// Create bus
		FamilyTiesEventStoreImpl.Config storeConfig = new FamilyTiesEventStoreImpl.Config();
		storeConfig.setExecutorService(executorService);
		FamilyTiesEventStore eventStore = new FamilyTiesEventStoreImpl(storeConfig);
		
		FamilyTiesEventBus.Config busConfig = new FamilyTiesEventBus.Config();
		busConfig.setStore(eventStore);
		busConfig.setExecutorService(executorService);
		
		busConfig.setInferencePolicy(InferencePolicy.EXCLUSIVE);
		
		FamilyTiesEventBus bus = new FamilyTiesEventBus(busConfig);
		
		// Bind rules.
		new DaughterRuleJavaBinder().bind(new DaughterRule(), bus);
		new GrandRulesJavaBinder().bind(new GrandRules(), bus);
		new ParentChildRulesJavaBinder().bind(new ParentChildRules(), bus);
		new ParentRulesJavaBinder().bind(new ParentRules(), bus);
		new SecondaryRulesJavaBinder().bind(new SecondaryRules(), bus);
		new SiblingRulesJavaBinder().bind(new SiblingRules(), bus);
		new SonRuleJavaBinder().bind(new SonRule(), bus);
		new SpouseRulesJavaBinder().bind(new SpouseRules(), bus);
		
		long start = System.currentTimeMillis();
		
		// Post seed relationships
		Person kate = new Person("Kate", 58, false);
		Person victor = new Person("Victor", 63, true);
		bus.post(new Spouse(kate, victor));

		Person peter = new Person("Peter", 37, true);
		bus.post(new Child(peter, kate));
		bus.post(new Child(peter, victor));
		
		Person alison = new Person("Alison", 36, false);
		bus.post(new Spouse(peter, alison));

		Person lucy = new Person("Lucy", 17, false);
		bus.post(new Child(lucy, alison));
		
		Person nancy = new Person("Nancy", 14, false);
		bus.post(new Child(nancy, peter));
		
		Person dan = new Person("Dan", 7, true);
		bus.post(new Child(dan, peter));
		bus.post(new Child(dan, alison));
		
		Person audrey = new Person("Audrey", 4, false);
		bus.post(new Child(audrey, peter));
		bus.post(new Child(audrey, alison));		
		
		Person tanya = new Person("Tanya", 31, false);
		Person max = new Person("Max", 32, true);
		bus.post(new Spouse(tanya, max));
		bus.post(new Child(tanya, kate));
		bus.post(new Child(tanya, victor));

		Person vilma = new Person("Vilma", 14, false);
		bus.post(new Child(vilma, tanya));
		
		Person george = new Person("George", 10, true);
		bus.post(new Child(george, tanya));
		
		Person lisa = new Person("Lisa", 5, false);
		bus.post(new Child(lisa, tanya));
		bus.post(new Child(lisa, max));		
				
		bus.join();

		StringBuilder sb = new StringBuilder();
		sb.append("Inference time (ms): "+(System.currentTimeMillis()-start)+"\n");
		for (Relative relative: bus.getStore().getRelatives(lisa)) {
			sb.append(relative+"\n");
		}
		executorService.shutdown();
		return sb.toString();
	}
	
	public static void main(String[] args) throws Exception {
//		Thread.sleep(60000);
		System.out.println(infer());
	}
	
}
