/*
@license.text@
 */
package com.hammurapi.eventbus.tests.familyties.rules;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.familyties.model.Husband;
import com.hammurapi.eventbus.tests.familyties.model.Spouse;
import com.hammurapi.eventbus.tests.familyties.model.Wife;

public class SpouseRules extends FamilyTiesRules {	
		
	/**
	 * If A is a spouse of B then B is a spouse of A. 
	 * @param spouse
	 */
	@Handler	
	public Spouse inferSpouse(Spouse spouse) {
		return new Spouse(spouse.getObject(), spouse.getSubject());
	}
		
	/**
	 * Male spouse is husband.
	 * @param spouse
	 */
	@Handler	
	public Husband inferHusband(@Condition("spouse.getSubject().isMale() && !(spouse instanceof com.hammurapi.eventbus.tests.familyties.model.Husband)") Spouse spouse) {
		return new Husband(spouse.getSubject(), spouse.getObject());
	}
	
	/**
	 * Female spouse is wife.
	 * @param spouse
	 */
	@Handler	
	public Wife inferWife(@Condition("!spouse.getSubject().isMale() && !(spouse instanceof com.hammurapi.eventbus.tests.familyties.model.Wife)") Spouse spouse) {
		return new Wife(spouse.getSubject(), spouse.getObject());
	}
}
