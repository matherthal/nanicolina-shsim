package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.extract.Extractor;

/**
 * Domain-specific event store extractor interface.
 *
 */
public interface FamilyTiesEventStoreExtractor<V> extends Extractor<AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,java.lang.Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, V, FamilyTiesEventStore> {

}
