/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class GrandMother extends GrandParent {

	public GrandMother(Person subject, Person object) {
		super(subject, object);
	}

}
