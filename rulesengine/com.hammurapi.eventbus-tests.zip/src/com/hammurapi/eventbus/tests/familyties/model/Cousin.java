/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Cousin extends Relative {

	public Cousin(Person subject, Person object) {
		super(subject, object);
	}

}
