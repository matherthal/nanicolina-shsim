/*
 @license.text@
 */
package com.hammurapi.eventbus.tests.familyties.model;


public class Spouse extends CloseRelative {

	public Spouse(Person subject, Person object) {
		super(subject, object);
	}

}
