package com.hammurapi.eventbus.tests.familyties;

import com.hammurapi.common.TokenExpander;
import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.Introspector;

/**
 * Domain specific introspector with bound generic parameters.
 */
public class FamilyTiesIntrospector extends Introspector<com.hammurapi.eventbus.tests.familyties.model.Relative, com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules, Long, AbstractEventBus.Handle<com.hammurapi.eventbus.tests.familyties.model.Relative,Integer,com.hammurapi.eventbus.tests.familyties.rules.FamilyTiesRules,Long>, FamilyTiesEventStore, FamilyTiesEventBus> {

	public FamilyTiesIntrospector(ClassLoader classLoader, TokenExpander tokenExpander) {
		super(classLoader, tokenExpander);
	}

}
