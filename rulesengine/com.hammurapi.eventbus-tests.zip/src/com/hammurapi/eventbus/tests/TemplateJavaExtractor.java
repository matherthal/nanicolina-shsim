package com.hammurapi.eventbus.tests;

import java.io.ObjectInputStream;
import java.util.List;
import java.util.Map;

import com.hammurapi.extract.CompiledExtractorBase;
import com.hammurapi.extract.Extractor;

// TODO - bind T, V, C. Predicate instead of Extractor if ...
@SuppressWarnings("unchecked")
class TemplateJavaExtractor<T, V, C> extends CompiledExtractorBase<T, V, C> {
	
	/**
	 * Class identity for comparison with other classes.
	 */
	private static final List<Object> IDENTITY;
	
	static {
		try {
			ObjectInputStream ois = new ObjectInputStream(TemplateJavaExtractor.class.getResourceAsStream("TemplateJavaExtractor.identity"));
			try {
				IDENTITY = (List<Object>) ois.readObject();
			} finally {
				ois.close();
			}
		} catch (Exception e) {
			throw new ExceptionInInitializerError(e);
		}
	}

	TemplateJavaExtractor(int[] map) {
		super(map, false, 0, 2); // TODO context dependency and parameter indices from template
	}

	@Override
	protected V extractInternal(C context, Map<C, Map<Extractor<T, ? super V, C>, ? super V>> cache, T... obj) {
		String p1 = (String) obj[map==null ? 0 : map[0]]; // TODO - Cast only if needed, loop.
		// TODO Auto-generated method stub
		return null; // TODO - expression.
	}

	@Override
	protected List<Object> getIdentity() {
		return IDENTITY;
	}

	@Override
	protected CompiledExtractorBase<T, V, C> newInstance(int[] map) {
		return new TemplateJavaExtractor<T, V, C>(map);
	}
	
}
