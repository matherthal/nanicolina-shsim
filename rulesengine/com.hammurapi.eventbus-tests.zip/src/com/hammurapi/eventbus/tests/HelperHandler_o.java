package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.tests.LocalEventBusTests.ObservableStringReference;

public class HelperHandler_o {
	
	private int worldCounter;
	private boolean worldOk;
	
	private int emCounter;
	private boolean emOk;
	
	public int getWorldCounter() {
		return worldCounter;
	}

	public boolean isWorldOk() {
		return worldOk;
	}

	public int getEmCounter() {
		return emCounter;
	}

	public boolean isEmOk() {
		return emOk;
	}

	@Handler("java(str)://str.get().equals(\"World\")")
	public void handleWorld(ObservableStringReference strRef) {
		++worldCounter;
		worldOk = "World".equals(strRef.get());
	}
	
	@Handler //("\"!\".equals(args[0])")
	public void handleEm(@Condition("\"!\".equals(strRef.get())") ObservableStringReference strRef) {
		++emCounter;
		emOk = "!".equals(strRef.get());
	}
}
