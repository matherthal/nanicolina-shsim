package com.hammurapi.eventbus.tests;

import java.util.HashSet;
import java.util.Set;

import com.hammurapi.eventbus.AbstractEventBus;
import com.hammurapi.eventbus.AbstractEventBus.Handle;
import com.hammurapi.eventbus.AbstractEventHandler;
import com.hammurapi.eventbus.EventDispatchContext;
import com.hammurapi.eventbus.EventHandler;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.JavaBinder;
import com.hammurapi.eventbus.local.LocalEventBus;
import com.hammurapi.eventbus.local.LocalEventDispatchJoinContext;
import com.hammurapi.eventbus.local.LocalEventStore;
import com.hammurapi.extract.Predicate;

public class TemplateJavaBinder implements JavaBinder<Object, Object, Long, AbstractEventBus.Handle<Object, Integer, Object, Long>, LocalEventStore<Object,Integer,Object>, LocalEventBus<Object, Integer, Object>, JoinHandler> {

	@Override
	public Set<Long> bind(JoinHandler instance, LocalEventBus<Object,Integer,Object> bus) {
		Set<Long> ret = new HashSet<Long>();
		
		ret.add(bindHandleHello(instance, bus));
		ret.add(bindJoin(instance, bus));
		
		return ret;
	}
	
	private Long bindHandleHello(final Object instance, LocalEventBus<Object, Integer, Object> bus) {
		
		Predicate<Object, Object>[] predicates = new Predicate[1];
		
		predicates[0] = null;
		
		boolean oneOff = false;
		
		Mode mode = Mode.POST;
		EventHandler<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> eventHandler = new AbstractEventHandler<Object, Integer, Object, AbstractEventBus.Handle<Object,Integer,Object,Long>, LocalEventStore<Object,Integer,Object>>(1, 0, instance, false, oneOff, mode , predicates) {

			@Override
			public void post(EventDispatchContext<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> context, Object... events) {
				((JoinHandler) instance).handleHello((String) events[0]);
			}
		};
		
		return bus.addHandler(eventHandler);
		
	}
	
	private Long bindJoin(final Object instance, LocalEventBus<Object, Integer, Object> bus) {
		
		Predicate<Object, Object>[] predicates = new Predicate[1];
		
		predicates[0] = null;
		boolean oneOff = false;
		
		EventHandler<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> eventHandler = new AbstractEventHandler<Object, Integer, Object, AbstractEventBus.Handle<Object,Integer,Object,Long>, LocalEventStore<Object,Integer,Object>>(3, 0, instance, false, oneOff, Mode.POST, predicates) {

			@Override
			public void post(EventDispatchContext<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> context, Object... events) {
				String arg0 = (String) events[0];
				String arg1 = (String) events[1];
				Integer arg2 = (Integer) events[2];
				((JoinHandler) instance).join(wrap(context), arg0, arg1, arg2);
			}

			private LocalEventDispatchJoinContext<Object, Integer, Object> wrap(final EventDispatchContext<Object, Integer, Object, Handle<Object, Integer, Object, Long>, LocalEventStore<Object, Integer, Object>> context) {
				return new LocalEventDispatchJoinContext<Object, Integer, Object>() {

					@Override
					public void post(Object event, Predicate<Object, LocalEventStore<Object, Integer, Object>>... validators) {
						context.post(event, validators);
					}

					@Override
					public void consume(int index) {
						context.consume(index);
					}

					@Override
					public void consume(Object event) {
						context.consume(event);
					}

					@Override
					public void update(Object event) {
						context.update(event);
					}

					@Override
					public void removeHandler() {
						context.removeHandler();
					}

					@Override
					public LocalEventStore<Object, Integer, Object> getEventStore() {
						return context.getEventStore();
					}

					@Override
					public void consumeJoin(int index) {
						context.consume(index);
					}

					@Override
					public void consumeJoin(Object event) {
						context.consume(event);
					}

					@Override
					public com.hammurapi.eventbus.EventHandlerBase.Mode getMode() {
						return context.getMode();
					}
					
				};
			}

		};
		
		return bus.addHandler(eventHandler);
		
	}


}
