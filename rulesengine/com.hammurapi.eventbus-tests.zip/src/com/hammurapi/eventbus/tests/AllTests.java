package com.hammurapi.eventbus.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.hammurapi.extract.java.test.JavaExtractorTests;

@RunWith(Suite.class)
@SuiteClasses({LocalEventBusTests.class,
	JavaExtractorTests.class,
	com.hammurapi.tests.AllTests.class})
public class AllTests {

}
