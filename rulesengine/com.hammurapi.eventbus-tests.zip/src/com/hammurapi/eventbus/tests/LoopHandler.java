package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;

public class LoopHandler {
	
	private int helloCounter;
	private boolean helloOk;
	
	public int getHelloCounter() {
		return helloCounter;
	}

	public boolean isHelloOk() {
		return helloOk;
	}
	
	private int worldCounter;
	private boolean worldOk;	
	
	public boolean isWorldOk() {
		return worldOk;
	}
	
	public int getWorldCounter() {
		return worldCounter;
	}

	@Handler("java(str)://str.equals(\"Hello\")")
	public String handleHello(String str) {
		++helloCounter;
		helloOk = "Hello".equals(str);
		return "World";
	}
	
	@Handler("java(str)://str.equals(\"World\")")
	public String handleWorld(String str) {
		++worldCounter;
		worldOk = "World".equals(str);
		return "Hello";
	}
}
