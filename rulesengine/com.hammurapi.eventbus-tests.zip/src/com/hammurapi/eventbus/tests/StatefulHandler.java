package com.hammurapi.eventbus.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.Resettable;

public class StatefulHandler implements Resettable {
	
	private volatile int counter;
	private volatile int resetCounter;
	
	public int getCounter() {
		return counter;
	}
	
	private volatile List<Object> state = Collections.synchronizedList(new ArrayList<Object>());
	
	@Handler
	public void handle(String str) {
		++counter;
		state.add(str);
	}
	
	@Handler
	public void handle(int i) {
		++counter;
		state.add(i);
	}
	
	public List<Object> getState() {
		return state;
	}

	@Override
	public void reset() {
		state.clear();
		++resetCounter;		
	}
	
	public int getResetCounter() {
		return resetCounter;
	}
	
}
