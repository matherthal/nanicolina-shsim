package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;

public class RemoveHandler {
	
	private int worldCounter;
	private boolean worldOk;
	
	private int emCounter;
	private boolean emOk;
	
	public int getWorldCounter() {
		return worldCounter;
	}

	public boolean isWorldOk() {
		return worldOk;
	}

	public int getEmCounter() {
		return emCounter;
	}

	public boolean isEmOk() {
		return emOk;
	}

	@Handler(value="java(str)://str.equals(\"World\")", mode=Mode.REMOVE)
	public void handleWorld(String str) {
		++worldCounter;
		worldOk = "World".equals(str);
	}
	
	@Handler(mode=Mode.REMOVE) //("\"!\".equals(args[0])")
	public void handleEm(LocalEventDispatchContext<Object, Integer, Object> context, @Condition("\"!\".equals(str)") String str) {
		++emCounter;
		emOk = "!".equals(str);
		context.post("Bye!");
	}
	
	
}
