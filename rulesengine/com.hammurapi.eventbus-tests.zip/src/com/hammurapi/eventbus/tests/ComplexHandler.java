package com.hammurapi.eventbus.tests;

import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;

public class ComplexHandler {
	
	@Handler
	public void handle(LocalEventDispatchContext<Object, Integer, ?> ctx, String str) throws InterruptedException {
		System.out.println("Handling with context '"+str+"' in "+Thread.currentThread());
		if ("mama".equals(str)) {
			ctx.post("papa");
		}
		Thread.sleep(100);
	}
	
	@Handler("java(str)://\"papa\".equals(str)")
	public String handle(String str) {
		System.out.println("Handling '"+str+"' in "+Thread.currentThread());
		return "grand";
	}
	
	@Handler
	public void handle(Integer num) {
		System.out.println("Handling '"+num+"' in "+Thread.currentThread());
	}	
	
	@Handler
	public void handle(String str, Integer num) throws InterruptedException {
		System.out.println("Joining "+str+" and "+num);
		Thread.sleep(100);
	}

}
