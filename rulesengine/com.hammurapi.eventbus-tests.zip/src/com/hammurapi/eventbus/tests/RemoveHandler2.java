package com.hammurapi.eventbus.tests;

import java.util.concurrent.atomic.AtomicReference;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.local.LocalEventDispatchContext;
import com.hammurapi.eventbus.Handler;

public class RemoveHandler2 {
	
	private Object expectedWorld;
	
	public void setExpectedWorld(Object expectedWorld) {
		this.expectedWorld = expectedWorld;
	}
	
	private int worldCounter;
	private boolean worldOk;
	
	public int getWorldCounter() {
		return worldCounter;
	}

	public boolean isWorldOk() {
		return worldOk;
	}

	@Handler(value="java(*)://strRef.get().equals(\"World\")", mode=Mode.REMOVE)
	public void handleWorld(AtomicReference<String> strRef) {
		++worldCounter;
		worldOk = expectedWorld == strRef;
	}
	
	private int emCounter;
	private boolean emOk;
	
	public int getEmCounter() {
		return emCounter;
	}

	public boolean isEmOk() {
		return emOk;
	}

	@Handler(mode=Mode.REMOVE)
	public void handleEm(
			LocalEventDispatchContext<Object, Integer, Object> context, @Condition("\"!\".equals(strRef.get())") AtomicReference<String> strRef) {
		++emCounter;
		emOk = "!".equals(strRef.get());
	}
	
	
}
