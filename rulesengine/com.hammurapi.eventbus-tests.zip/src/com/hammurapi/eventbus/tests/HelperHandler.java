package com.hammurapi.eventbus.tests;

import java.util.concurrent.atomic.AtomicReference;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;

public class HelperHandler {
	
	private int worldCounter;
	private boolean worldOk;
	
	private int emCounter;
	private boolean emOk;
	
	public int getWorldCounter() {
		return worldCounter;
	}

	public boolean isWorldOk() {
		return worldOk;
	}

	public int getEmCounter() {
		return emCounter;
	}

	public boolean isEmOk() {
		return emOk;
	}

	@Handler("java(str)://str.get().equals(\"World\")")
	public void handleWorld(AtomicReference<String> strRef) {
		++worldCounter;
		worldOk = "World".equals(strRef.get());
	}
	
	@Handler //("\"!\".equals(args[0])")
	public void handleEm(@Condition("\"!\".equals(strRef.get())") AtomicReference<String> strRef) {
		++emCounter;
		emOk = "!".equals(strRef.get());
	}
}
