package com.hammurapi.eventbus.tests;

import com.hammurapi.common.Condition;
import com.hammurapi.eventbus.Handler;
import com.hammurapi.eventbus.EventHandlerBase.Mode;
import com.hammurapi.eventbus.local.LocalEventDispatchJoinContext;

public class JoinRemoveHandler {
		
	private int joinCounter;
	private boolean joinOk;	
	
	public boolean isJoinOk() {
		return joinOk;
	}
	
	public int getJoinCounter() {
		return joinCounter;
	}

	@Handler(mode=Mode.REMOVE, value="java(*)://world.equals(\"World\")")
	public void join(
			LocalEventDispatchJoinContext<Object, Integer, Object> context, 
			@Condition("\"Hello\".equals(hello)") String hello, 
			String world) {
		++joinCounter;
		joinOk = "Hello".equals(hello) && "World".equals(world) && Mode.REMOVE.equals(context.getMode());
	}
}
